import { APP_INITIALIZER, Inject, Injectable, NgModule, PLATFORM_ID } from '@angular/core';
import { BrowserModule, TransferState } from '@angular/platform-browser';
import { AppRoutingModule } from './app-routing.module';
import { AppComponent } from './app.component';
import { Global } from './global';
import { HttpClient, HttpClientModule, HTTP_INTERCEPTORS } from '@angular/common/http';
import { ServiceWorkerModule } from '@angular/service-worker';
import { environment } from '../environments/environment';
import { TranslateLoader, TranslateModule } from '@ngx-translate/core';
import { BrowserAnimationsModule } from '@angular/platform-browser/animations';
import { translateBrowserLoaderFactory } from './shared/translate-loader/translate-browser.loader';
import { NoCacheHeadersInterceptor } from './shared/interceptor/interceptor';
import { PageNotFoundComponent } from './shared/fallback/page-not-found/page-not-found.component';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { MatAutocompleteModule } from '@angular/material/autocomplete';
import { MatBadgeModule } from '@angular/material/badge';
import { MatIconModule } from '@angular/material/icon';
import { MatInputModule } from '@angular/material/input';
import { MatSelectModule } from '@angular/material/select';
import { UniversalInterceptor } from './shared/interceptor/universal-interceptor';
import { AuthGuard } from './shared/guards/auth.guard';
import { ConfigurationProvider, ConfigureConfiguration, LandingService, VsEcomStorefrontServicesModule } from '@vsecom/vs-ecom-storefront-services';
import { VssuiteEcomModule } from '@vssuite/vs-angular-ecom-components';
import { MatExpansionModule } from '@angular/material/expansion';
import { MatMenuModule } from '@angular/material/menu';
import { DOCUMENT, isPlatformBrowser, ɵgetDOM } from '@angular/common';
import { PrebootModule } from 'preboot';

export function prebootApp(document: HTMLDocument, platformId: Object) {
  return () => {
    if (isPlatformBrowser(platformId)) {
      const dom = ɵgetDOM();
      const styles: any[] = Array.prototype.slice.apply(document.querySelectorAll(`style[ng-transition]`));
      styles.forEach(el => {
        el.removeAttribute('ng-transition');
      });
      document.addEventListener('PrebootComplete', () => {
        setTimeout(() => styles.forEach(el => dom.remove(el)));
      });
    }
  };
}

export function initApp(configurationStore: ConfigurationStore, global: Global) {
  return () => {
    return new Promise<void>((resolve) => {
      configurationStore.getApiURL().subscribe(async (data: any) => {
        await configurationStore.setAppSettings(data);
        if (global.isApiUrlAvailable) {
          resolve();
        }
      });
    });
  };
}

export function loadConfig(configurationStore: ConfigurationStore) {
  return () => {
    return new Promise<void>((resolve) => {
      configurationStore.getConfigData().subscribe((data: any) => {
          configurationStore.setConfigData(data);
          resolve();
      });
    });
  };
}

export function loadNoChange(configurationStore: ConfigurationStore) {
  return () => {
    return new Promise<void>((resolve) => {
      configurationStore.getNoChange().subscribe((data: any) => {
        configurationStore.setNoChange(data);
        resolve();
      });
    });
  };
}


@Injectable({ providedIn: 'root' })
export class ConfigurationStore {

  private internalConfig: ConfigureConfiguration = { endPoint: '', storeReferenceId: '', branchId: '', storeId: ''};

  constructor(private httpClient: HttpClient, @Inject(PLATFORM_ID) private platformId: object, private global: Global) { }

  async setAppSettings(config: ConfigureConfiguration) {
    let apiUrl: string = config.endPoint + 'GetStoreInfo/' + config.storeReferenceId;
    await this.getStoreBranches(apiUrl).then((response: any) => {
      config.branchId = response['branches'][0]['branchId'];
      config.storeId = response['storeId'];
      this.internalConfig = config;
      this.global.isApiUrlAvailable = true;
      this.global.storeReferenceId = config.storeReferenceId;
    })
  }

  async getStoreBranches(apiUrl: string): Promise<any> {
    return this.httpClient.get(apiUrl).toPromise();
  }

  getAppSettings() {
    return this.internalConfig;
  }

  getApiURL() {
    return this.httpClient.get("assets/vsecom-appSettings.json");
  }

  getConfigData() {
    return this.httpClient.get("vsecom-config/config_data.json");
  }
  getNoChange() {
    return this.httpClient.get("vsecom-config/no_change.json");
  }

  
  setConfigData(data: any) {
    this.global.configPages = data.pages;
    this.global.configData = data.elements;
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('configData', JSON.stringify(data.elements));
      localStorage.setItem('pages', JSON.stringify(data.pages));
    }
  }

  setNoChange(data: any) {
    this.global.storeLogo = data.storeLogo;
    this.global.metaTags = data.metaTags;
    this.global.contactInfo = data.contactInfo;
    this.global.socialMediaLinks = data.socialMediaLinks;

    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('logo', data.storeLogo);
      localStorage.setItem('metaTags', JSON.stringify(data.metaTags));
      localStorage.setItem('contactInfo', JSON.stringify(data.contactInfo));
      localStorage.setItem('socialMediaLinks', JSON.stringify(data.socialMediaLinks));

    }
  }

}

@Injectable({ providedIn: 'root' })
export class ConfigFromApp implements ConfigurationProvider {

  constructor(private configStore: ConfigurationStore) { }

  get config(): ConfigureConfiguration {
    return this.configStore.getAppSettings();
  }
}

@NgModule({
  declarations: [
    AppComponent,
    PageNotFoundComponent
  ],
  imports: [
    BrowserModule.withServerTransition({ appId: 'serverApp' }),
    BrowserAnimationsModule,
    AppRoutingModule,
    HttpClientModule,
    ServiceWorkerModule.register('ngsw-worker.js', {
      enabled: environment.production,
      registrationStrategy: 'registerWhenStable:30000',
    }),
    TranslateModule.forRoot({
      loader: {
        provide: TranslateLoader,
        useFactory: translateBrowserLoaderFactory,
        deps: [HttpClient, TransferState]
      }
    }),
    MatFormFieldModule,
    MatAutocompleteModule,
    FormsModule,
    MatInputModule,
    ReactiveFormsModule,
    FormsModule,
    MatSelectModule,
    MatIconModule,
    MatBadgeModule,
    VssuiteEcomModule,
    MatMenuModule,
    MatExpansionModule,
    VsEcomStorefrontServicesModule.forRoot({
      config: {
        provide: ConfigurationProvider,
        useClass: ConfigFromApp,
      },
    }),
    PrebootModule.withConfig({ appRoot: 'app-root' })
  ],
  providers: [
    {
      provide: APP_INITIALIZER,
      useFactory: prebootApp,
      deps: [DOCUMENT, PLATFORM_ID],
      multi: true
    },
    {
      provide: APP_INITIALIZER,
      useFactory: initApp,
      multi: true,
      deps: [ConfigurationStore, Global],
    },
    {
      provide: APP_INITIALIZER,
      useFactory: loadConfig,
      deps: [ConfigurationStore],
      multi: true,
    },
    {
      provide: APP_INITIALIZER,
      useFactory: loadNoChange,
      deps: [ConfigurationStore],
      multi: true,
    },

    {
      provide: HTTP_INTERCEPTORS,
      useClass: UniversalInterceptor,
      multi: true
    },
    {
      provide: HTTP_INTERCEPTORS,
      useClass: NoCacheHeadersInterceptor,
      multi: true
    },
    TransferState,
    AuthGuard,
    Global
  ],
  bootstrap: [AppComponent],
})
export class AppModule { }
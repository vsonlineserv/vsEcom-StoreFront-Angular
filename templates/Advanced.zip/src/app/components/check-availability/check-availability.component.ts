import { Component, Inject, OnInit } from '@angular/core';
import { MatDialogRef, MAT_DIALOG_DATA } from '@angular/material/dialog';
import { ProductService } from '@vsecom/vs-ecom-storefront-services';

@Component({
  selector: 'app-check-availability',
  templateUrl: './check-availability.component.html',
  styleUrls: ['./check-availability.component.css']
})
export class CheckAvailabilityComponent implements OnInit {

  ProductId: any;
  BranchId: any;

  contactDataSaved: boolean;
  contactDataNotSaved: boolean;
  contactDataSavedFailure: boolean;
  flagLocationBased: boolean = true;
  product: any = [];

  constructor(public dialogRef: MatDialogRef<CheckAvailabilityComponent>, @Inject(MAT_DIALOG_DATA) public data: any,
    private productService: ProductService) {

  }

  ngOnInit(): void {
    this.ProductId = this.data.productId;
    this.BranchId = this.data.branchId;
    this.loadProduct()
  }

  loadProduct() {
    this.productService.GetProductDetails(this.ProductId, this.flagLocationBased).subscribe((response: any) => {
      Object.assign(this.product, response);

    })
  }

  contactSeller(event:any) {
    this.productService.ContactSeller(event.contactData.Name,event.contactData.Email,event.contactData.Mobile,event.contactData.Subject, this.BranchId, this.ProductId).subscribe((result: any) => {
      if (result == "failed") {
        this.contactDataSavedFailure = true;
      }
      else if (result == "success") {
        this.contactDataSaved = true;
      }
      else {
        this.contactDataNotSaved = true;
      }
    });
  }

  close() {
    this.dialogRef.close();
  }

}




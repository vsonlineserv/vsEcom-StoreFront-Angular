import { Component, ComponentRef, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Global } from '../global';
import { ProductService } from '@vsecom/vs-ecom-storefront-services';
import { GlobalService } from '../service/global.service';
import { isPlatformBrowser } from '@angular/common';
import { LandingService } from '@vsecom/vs-ecom-storefront-services';

@Component({
  selector: 'app-home',
  templateUrl: './home.component.html',
  styleUrls: ['./home.component.css']
})
export class HomeComponent implements OnInit {

  featuredProducts: any = [];
  topCategoriesList: any = [];
  carouselList:any=[];
  offerProducts: any = [];
  messageOffers: any = '';
  offerTitleImg: boolean = false;

  constructor(public global: Global, private landingService: LandingService, private router: Router, private titleService: Title, private meta: Meta, private activatedRoute: ActivatedRoute,
    public translateService: TranslateService, private productsService: ProductService, public globalService: GlobalService, @Inject(PLATFORM_ID) private platformId: object) {
    translateService.use('en-us');
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(data => {
      this.globalService.updataDynamicSEO(data['noChangeData']['metaTags']['Home']);
      this.getCurrency();
      this.getFeaturedProducts();
      this.getAllOffers();
      this.getTopCategories();
      this. getCarousel();
    });
  }
  getCarousel() {
    if(this.global.configData && this.global.configData.HeroCarousel && this.global.configData.HeroCarousel.data) {
      for(let i=0;i<this.global.configData.HeroCarousel.data.length;i++){
        if(this.global.configData.HeroCarousel.data[i].vsShowContentBox){
          this.carouselList.push(this.global.configData.HeroCarousel.data[i])
        }
    }
    }
  }

  getCurrency() {
    this.landingService.GetCurrency().subscribe((response: any) => {
      if (isPlatformBrowser(this.platformId)) {
        if (response.symbol != null) {
          localStorage.setItem('currency', response.symbol);
          this.global.currency = response.symbol;
        }
        if (response.taxType) {
          localStorage.setItem('taxType', response.taxType);
          this.global.taxType = response.taxType;
        }
      }
    });
  }

  getFeaturedProducts() {
    this.landingService.GetFeaturedProducts().subscribe((data) => {
      this.featuredProducts = data;
    }),
      error => {

      }
  }

  getAllOffers() {
    this.productsService.GetAllOffers().subscribe((response: any) => {
      this.offerProducts = response;
      if (this.offerProducts && this.offerProducts.length == 0) {
        this.messageOffers = 'No Offers in selected Area.'
      }
    });
  }

  getTopCategories() {
    this.landingService.GetTopCategoriesList().subscribe((data) => {
      this.topCategoriesList = data;
    }),
      error => {

      }
  }

  navigateCategoriesPage(event) {
    this.router.navigate(['category/' + event.categoryName + '/' + event.categoryId]);
  }


  navigateOffersPage() {
    this.router.navigate(['offers'])
  }

}

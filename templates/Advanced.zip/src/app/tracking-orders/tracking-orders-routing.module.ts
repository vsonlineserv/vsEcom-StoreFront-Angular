import { NgModule } from '@angular/core';
import { RouterModule, Routes } from '@angular/router';
import { TrackingOrdersComponent } from './tracking-orders.component';

const routes: Routes = [
  {
    path: '', component: TrackingOrdersComponent, pathMatch: 'full'
  }
];

@NgModule({
  imports: [RouterModule.forChild(routes)],
  exports: [RouterModule]
})
export class TrackingOrdersRoutingModule { }

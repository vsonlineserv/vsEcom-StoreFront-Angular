import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { FormGroup } from '@angular/forms';
import { NavigationExtras, Router } from '@angular/router';
import { UserActionService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../global';
import { isPlatformBrowser } from '@angular/common';
import { GlobalService } from '../service/global.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-tracking-orders',
  templateUrl: './tracking-orders.component.html',
  styleUrls: ['./tracking-orders.component.css']
})
export class TrackingOrdersComponent implements OnInit {

  TrackOrdersList: any = [];
  currency: any;
  ProductList: any = [];
  panelOpenState: boolean = false;
  matExpantValue: any = '';
  searchOrderId: any = '';
  searchForm: FormGroup;
  message: any = '';
  ordersCount: number = 0;
  showNoProducts: boolean = false;

  constructor(private useractionService: UserActionService, private router: Router, 
    public global: Global, @Inject(PLATFORM_ID) private platformId: object, 
    private globalService: GlobalService, private spinner: NgxSpinnerService) {

  }

  async ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.currency = localStorage.getItem("currency");
    }
    this.getOrders();
  }

  getOrders() {
    this.spinner.show();
    this.useractionService.GetTrackingOrders().subscribe((response: any) => {
      this.spinner.hide();
      if (response && response.length > 0) {
        Object.assign(this.TrackOrdersList, response);
        if (this.TrackOrdersList) {
          this.ordersCount = this.TrackOrdersList.length;
        }
        this.displayNoProducts();
      }
    }, error => {
      this.spinner.hide();
      this.displayNoProducts();
    });
  }

  viewOrderedProducts(orders: any, expandId: any) {
    this.ProductList = [];
    var orderId = orders.id;
    this.spinner.show();
    this.useractionService.GetProductList(orderId).subscribe((response: any) => {
      this.spinner.hide();
      Object.assign(this.ProductList, response);
      if (expandId == this.matExpantValue) {
        this.matExpantValue = '';
      } else {
        this.matExpantValue = expandId;
      }
    }, error => {
      this.spinner.hide();
    })
  }


  cancelOrders(orders) {
    var flagCancelOrder = window.confirm('Are you sure you want to Cancel Order? \n Order Number : ' + orders.id + '\n Number of products: ' + orders.numberOfProducts
      + '\n Order Status: ' + orders.orderStatus + '\n Order Total: ' + orders.orderTotal);
    if (flagCancelOrder) {
      var orderId = orders.id;
      this.useractionService.CancelOrders(orderId).subscribe((response) => {
        if (response === true) {
          //  savedSuccessfully = true;
          let message = "Order Number " + orderId + " Cancelled";
          alert(message);
          this.getOrders();
        }
        else {
          //  $scope.savedSuccessfully = false;
          let message = "Error Cancelled " + orderId;
          alert(message);
        }
      });
    }
  }

  navigatePrintPage(value: any) {
    var orderId = value
    if (orderId != null || orderId != undefined) {
      let navigationExtras: NavigationExtras = {
        state: {
          id: orderId
        }
      };
      this.router.navigate(['/confirm-order'], navigationExtras)
    }
  }

  searchOrders() {
    if (this.searchOrderId > 0) {
      this.useractionService.SearchOrders(this.searchOrderId).subscribe((response: any) => {
        if (response.length > 0) {
          Object.assign(this.TrackOrdersList, response);
          this.TrackOrdersList = response;
        } else {
          this.getOrders();
        }
      },
        function (err) {

        });
    } else {
      this.getOrders();
    }
  }

  getISTDate(orderDateUtc) {
    var IST = new Date(orderDateUtc + 'Z'); // Clone UTC Timestamp
    return IST;
  }

  displayNoProducts() {
    if (this.TrackOrdersList && this.TrackOrdersList.length == 0) {
      this.showNoProducts = true;
    }
  }

  navigateHomePage(){
    if (isPlatformBrowser(this.platformId)) {
      window.scrollTo(0,0);
      this.router.navigate(['home'])
    }
  }

}

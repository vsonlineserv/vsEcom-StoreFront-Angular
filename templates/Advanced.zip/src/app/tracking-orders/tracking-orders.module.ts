import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { TrackingOrdersRoutingModule } from './tracking-orders-routing.module';
import { TranslateModule } from '@ngx-translate/core';
import { TrackingOrdersComponent } from './tracking-orders.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import {MatExpansionModule} from '@angular/material/expansion';
import { NgxSpinnerModule } from 'ngx-spinner';
@NgModule({
  declarations: [TrackingOrdersComponent],
  imports: [
    CommonModule,
    TrackingOrdersRoutingModule,
    TranslateModule,
    FormsModule,
    ReactiveFormsModule,
    MatExpansionModule,
    NgxSpinnerModule
  ]
})
export class TrackingOrdersModule { }

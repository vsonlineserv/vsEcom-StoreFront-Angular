import { isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { Meta, MetaDefinition, Title } from '@angular/platform-browser';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Global } from '../global';
import { CartService } from '@vsecom/vs-ecom-storefront-services';
import { UserActionService } from '@vsecom/vs-ecom-storefront-services';

@Injectable({
  providedIn: 'root'
})
export class GlobalService {

  cartTotal: any = 0;
  tokenResult: any;

  constructor(private httpClient: HttpClient, private global: Global, private router: Router, private cartService: CartService, private titleService: Title, private meta: Meta,
    private userActionService: UserActionService, @Inject(PLATFORM_ID) private platformId: object, private translate: TranslateService) {
    translate.use('en-us');
  }

  //STORAGE METHODS

  SetLoggedInUserToken(tokenObj: any) {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.setItem('loggedInUserToken', JSON.stringify(tokenObj));
      this.global.loggedInUserToken.access_token = tokenObj.accessToken;
      this.global.loggedInUserToken.expires_in = tokenObj.validDateUTC;
    }
  }

  GetLoggedInUserToken() {
    if (isPlatformBrowser(this.platformId)) {
      this.tokenResult = JSON.parse(localStorage.getItem('loggedInUserToken'));
    }
    if (!this.tokenResult) {
      return false;
    }
    this.global.loggedInUserToken.access_token = this.tokenResult.accessToken;
    this.global.loggedInUserToken.expires_in = this.tokenResult.validDateUTC;
    return true;
  }

  ClearCookieStore() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('userName');
      localStorage.removeItem('flagLoggedIn');
      localStorage.removeItem('curUserDisplayName');
    }
  }

  //LOGOUT METHOD

  Logout() {
    if (isPlatformBrowser(this.platformId)) {
      localStorage.removeItem('userName');
      localStorage.removeItem('flagLoggedIn');
      localStorage.removeItem('curUserDisplayName');
      localStorage.removeItem('loggedInUserToken');
      this.global.curUserDisplayName = '';
      this.global.userName = '';
      this.global.flagLoggedIn = false;
      this.global.loggedInUserToken.access_token = '';
      this.global.wishListCount = 0;
      this.router.navigate(['home'])
    }
  }

  //COMMON METHODS 

  incrementProductQuantity(product) {
    for (var i = 0; i < this.global.cartlist.length; i++) {
      if (this.global.cartlist[i].ProductId == product.ProductId) {
        this.global.cartlist[i].Quantity = (this.global.cartlist[i].Quantity * 1) + 1;
        this.global.cartlist[i].TotalAdditionalShippingCharge = this.global.cartlist[i].AdditionalShippingCharge * this.global.cartlist[i].Quantity;
        this.global.cartlist[i].SubTotal = (this.global.cartlist[i].SpecialPrice * this.global.cartlist[i].Quantity);
        this.global.cartlist[i].SubTotalWithShipping = (this.global.cartlist[i].SpecialPrice * this.global.cartlist[i].Quantity) + this.global.cartlist[i].TotalAdditionalShippingCharge;
        if (this.global.userName != "" && this.global.userName != null) {
          this.cartService.UpdateCartItemQuantity(this.global.cartlist[i], this.global.userName).subscribe((response: any) => {
            if (response != '') {
              this.global.totalSaved = 0;
              for (var i = 0; i < response.length; i++) {
                this.global.totalSaved = this.global.totalSaved + response[i].totalSaved;
              }
            }
          });
        }
      }
    }
    this.CalculateCartTotal();
  }

  decrementProductQuantity(product) {
    for (var i = 0; i < this.global.cartlist.length; i++) {
      if (this.global.cartlist[i].ProductId == product.ProductId) {
        if (this.global.cartlist[i].Quantity > 0) {
          this.global.cartlist[i].Quantity = (this.global.cartlist[i].Quantity * 1) - 1;

          this.global.cartlist[i].TotalAdditionalShippingCharge = this.global.cartlist[i].AdditionalShippingCharge * this.global.cartlist[i].Quantity;
          this.global.cartlist[i].SubTotal = (this.global.cartlist[i].SpecialPrice * this.global.cartlist[i].Quantity);
          this.global.cartlist[i].SubTotalWithShipping = (this.global.cartlist[i].SpecialPrice * this.global.cartlist[i].Quantity) + this.global.cartlist[i].TotalAdditionalShippingCharge;
          if (this.global.cartlist[i].Quantity >= 1) {
            if (this.global.userName != "" && this.global.userName != null) {
              this.cartService.UpdateCartItemQuantity(this.global.cartlist[i], this.global.userName).subscribe((response: any) => {
                if (response != '') {
                  this.global.totalSaved = 0;
                  for (var i = 0; i < response.length; i++) {
                    this.global.totalSaved = this.global.totalSaved + response[i].totalSaved;
                  }
                }
              });
            }
          } else {
            this.removeProductFromCart(product);
          }
        }
      }
      this.CalculateCartTotal();
    }
  }

  CalculateCartTotal() {
    this.global.cartTotal = 0;
    this.global.cartCount = 0;
    if (this.global.cartlist) {
      for (var i = 0; i < this.global.cartlist.length; i++) {
        this.global.cartTotal = this.global.cartTotal + this.global.cartlist[i].SubTotal;
        this.global.cartCount = this.global.cartlist.length;
        if (this.global.cartlist[i].TotalAdditionalShippingCharge != null) {
          this.global.cartTotal += this.global.cartlist[i].TotalAdditionalShippingCharge;
        }
      }
    }
    if (this.global.cartlist && this.global.cartlist.length > 0) {
      if (isPlatformBrowser(this.platformId)) {
        localStorage.setItem('cartTotal', this.global.cartTotal.toString());
        localStorage.setItem('cartlist', JSON.stringify(this.global.cartlist));
      }
    }
  }

  removeProductFromCart(product: any) {
    var removeElement = -1;
    for (var i = 0; i < this.global.cartlist.length; i++) {
      if (this.global.cartlist[i].ProductId == product.ProductId) {
        removeElement = i;
      }
    }
    if (removeElement > -1) {
      var removedcartItem = this.global.cartlist.splice(removeElement, 1);
      if (removedcartItem.length > 0 && this.global.flagLoggedIn) {
        this.cartService.RemoveShoppingCartItem(removedcartItem[0], this.global.userName).subscribe((response: any) => {
          if (response != '') {
            this.global.totalSaved = 0;
            for (var i = 0; i < response.length; i++) {
              this.global.totalSaved = this.global.totalSaved + response[i].totalSaved;
            }
          }
        })
      }
      if (this.global.cartlist && this.global.cartlist.length > 0) {
        if (isPlatformBrowser(this.platformId)) {
          localStorage.setItem('cartlist', JSON.stringify(this.global.cartlist));
        }
      }
      else {
        if (isPlatformBrowser(this.platformId)) {
          localStorage.removeItem('cartlist');
          this.global.vsShowEmptyCart = true;
        }
      }
    }
    this.CalculateCartTotal();
  }

  // NAVIGATE ROUTES METHODS //

  goToPreviousPage() {
    history.back();
  }

  navigateProductDetails(event) {
    window.scrollTo(0, 0);
    this.router.navigate(['product/' + event.ProductName + '/' + event.ProductId]);
  }

  // AUTH GUARD METHODS //

  checkTokenExist() {
    if (this.GetLoggedInUserToken()) {
      return true;
    }
    return false;
  }

  checkTokenValid() {
    if (this.checkIsAuthenticated()) {
      if (this.GetLoggedInUserToken()) {
        let datenow = new Date();
        let dateUtcnow = new Date(datenow).toISOString();
        let sysDate = Date.parse(dateUtcnow);
        let expiresUtc = new Date(this.global.loggedInUserToken.expires_in).toISOString();
        let expireDate = Date.parse(expiresUtc);
        if (sysDate > expireDate) {
          return false;
        }
        if (isNaN(expireDate)) {
          return false;
        }
        return true;
      }
      return false;
    }
    return false;
  }

  checkIsAuthenticated() {
    if (this.GetIsFlagAuthenticated()) {
      return true;
    }
    return false;
  }

  GetIsFlagAuthenticated() {
    if (isPlatformBrowser(this.platformId)) {
      let result = JSON.parse(localStorage.getItem('flagLoggedIn'));
      if (result == null || result == 'false' || !result) {
        return false;
      }
    }
    return true;
  }

  // STATIC META SERVICE

  updateTitle(title: string) {
    this.translate.get('Header.STORENAME_TITLE').subscribe((translated: string) => {
      this.titleService.setTitle(translated + ' | ' + title);
    });
  }

  updateMetaTags(metaTags: MetaDefinition[]) {
    metaTags.forEach(m => this.meta.updateTag(m));
    this.meta.updateTag({ property: 'og:image', content: this.global.storeLogo });
    this.meta.updateTag({ property: 'og:image:secure_url', content: this.global.storeLogo });
    this.meta.updateTag({ property: 'twitter:image', content: this.global.storeLogo });
    this.meta.updateTag({ property: 'twitter:image:secure_url', content: this.global.storeLogo });
  }

  // DYNAMIC META SERVICE

  updataDynamicSEO(metaInfo: any) {
    if (metaInfo) {
      this.titleService.setTitle(metaInfo.title);
      this.meta.updateTag({ property: 'og:title', content: metaInfo.ogTitle });
      this.meta.updateTag({ property: 'og:url', content:  metaInfo.url });
      this.meta.updateTag({ name: 'og:description', content: metaInfo.description });
      this.meta.updateTag({ property: 'description', content: metaInfo.description });
      this.meta.updateTag({ property: 'keywords', content: metaInfo.keywords });
      this.meta.updateTag({ property: 'twitter:title', content: metaInfo.ogTitle });
      this.meta.updateTag({ name: 'twitter:description', content: metaInfo.description });
      this.meta.updateTag({ property: 'twitter:image', content: metaInfo.image });
      this.meta.updateTag({ property: 'og:image', content: metaInfo.image });
    }
  }

  //DYNAMIC PAGE SERVICE

  getSharedContent(content: any) {
    const httpOptions = {
      responseType: 'text' as 'json'
    }
    return this.httpClient.get("assets/shared/" + content + ".html", httpOptions);
  }

}

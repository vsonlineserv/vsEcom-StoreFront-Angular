import { isPlatformBrowser } from '@angular/common';
import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Global } from '../../../global'

@Component({
  selector: 'app-page-not-found',
  templateUrl: './page-not-found.component.html',
  styleUrls: ['./page-not-found.component.css']
})
export class PageNotFoundComponent implements OnInit {

  constructor(@Inject(PLATFORM_ID) private platformId: object, public global: Global, private translate: TranslateService, private router: Router) { 
    translate.use('en-us');
  }

  ngOnInit(): void {
    this.global.showNotfoundPage = true;
    if (isPlatformBrowser(this.platformId)) {
      this.global.configData = JSON.parse(localStorage.getItem('configData'))
    }
  }

  navigateHomePage() {
    this.global.showNotfoundPage = false;
    this.router.navigate([''])
  }

}

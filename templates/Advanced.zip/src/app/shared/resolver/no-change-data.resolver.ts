import { Injectable } from '@angular/core';
import {
  Router, Resolve,
  RouterStateSnapshot,
  ActivatedRouteSnapshot
} from '@angular/router';
import { catchError, Observable, of } from 'rxjs';
import { ConfigurationStore } from 'src/app/app.module';

@Injectable({
  providedIn: 'root'
})
export class NoChangeDataResolver implements Resolve<any> {

  constructor(public configurationStore: ConfigurationStore) { }

  resolve() {
    return this.configurationStore.getNoChange().pipe(
      catchError((error) => {
        return of('No data');
      })
    )
  }
  
}

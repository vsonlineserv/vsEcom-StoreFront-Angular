import { TestBed } from '@angular/core/testing';

import { NoChangeDataResolver } from './no-change-data.resolver';

describe('NoChangeDataResolver', () => {
  let resolver: NoChangeDataResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    resolver = TestBed.inject(NoChangeDataResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});

export class UserToken {
  access_token: string;
  expires_in: number;
}

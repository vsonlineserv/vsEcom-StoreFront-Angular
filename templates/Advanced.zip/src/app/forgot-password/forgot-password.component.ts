import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Global } from '../global';
import { GlobalService } from '../service/global.service';
import { PasswordService } from '@vsecom/vs-ecom-storefront-services';

@Component({
  selector: 'app-forgot-password',
  templateUrl: './forgot-password.component.html',
  styleUrls: ['./forgot-password.component.css']
})
export class ForgotPasswordComponent implements OnInit {

 
  submitted = false;
  message: any = '';
  forgotPasswordForm: FormGroup;
  successfullySent: boolean;

  constructor(private passwordService: PasswordService, public global: Global, public globalService: GlobalService) {
    this.forgotPasswordForm = new FormGroup({
      Email: new FormControl('', [Validators.required]),
    });
   }

  async ngOnInit() {
  }

  handleForgotPassword(){
    this.submitted = true;
    if (!this.forgotPasswordForm.valid) {
        return;
    }
  }
  SendForgetPassword() {
    this.passwordService.ForgotPassword(this.forgotPasswordForm.value.Email).subscribe (response => {
         if (response == false) {
             this.message = 'Sorry. Unable to identify user. Please verify provided email id'
             this.successfullySent = false
         }
         else {
             this.message = 'A link has been sent to your mail to reset the password'
             this.successfullySent = true;
         }
     });
};
}

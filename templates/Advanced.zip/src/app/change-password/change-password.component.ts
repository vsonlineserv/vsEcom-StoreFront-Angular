import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { GlobalService } from '../service/global.service';
import { PasswordService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../global';
import { isPlatformBrowser } from '@angular/common';
@Component({
  selector: 'app-change-password',
  templateUrl: './change-password.component.html',
  styleUrls: ['./change-password.component.css']
})
export class ChangePasswordComponent implements OnInit {

  message: any = '';
  changePasswordForm: FormGroup;
  savedSuccessfully: boolean = false;
  submitted: boolean = false;
  passwordVisible: boolean = false;
  passwordVisible1: boolean = false;
  passwordVisible2: boolean = false;


  constructor(private passwordService: PasswordService, public global: Global, private globalService: GlobalService, private router: Router, 
    @Inject(PLATFORM_ID) private platformId: object) {
    this.changePasswordForm = new FormGroup({
      CurrentPassword: new FormControl('', [Validators.required]),
      NewPassword: new FormControl('', [Validators.required,Validators.minLength(6)]),
      ConfirmPassword: new FormControl('', [Validators.required])
    });
  }

  async ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.global.userName = localStorage.getItem('userName')
    }
  }
  
  togglePasswordVisibility() {
    let npw : any;
    npw = document.getElementById("newPassword");
    if (npw.type === "password") {
      npw.type = "text";
      this.passwordVisible = true;
    } else {
      npw.type = "password";
      this.passwordVisible = false;
    }
  }
  togglePasswordVisibility1() {
    let npw : any;
    npw = document.getElementById("newPassword1");
    if (npw.type === "password") {
      npw.type = "text";
      this.passwordVisible1 = true;
    } else {
      npw.type = "password";
      this.passwordVisible1 = false;
    }
}
togglePasswordVisibility2() {
  let npw : any;
  npw = document.getElementById("confirmPassword");
  if (npw.type === "password") {
    npw.type = "text";
    this.passwordVisible2 = true;
  } else {
    npw.type = "password";
    this.passwordVisible2 = false;
  }
}

  changePassword() {
    this.submitted = true;
    if (!this.changePasswordForm.valid) {
      return;
    }
    if (this.changePasswordForm.value.NewPassword === this.changePasswordForm.value.ConfirmPassword) {
      this.passwordService.ChangePassword(this.changePasswordForm.value).subscribe(response => {
        if (response == true) {
          this.savedSuccessfully = true;
          this.message = "Password has been changed Successfully."
        }
        else {
          this.savedSuccessfully = false;
          this.message = "Error in updating Password"
        }

      }, error => {
        this.savedSuccessfully = false;
        this.message = error.error;
      })
    }
    else {
      this.savedSuccessfully = false;
      this.message = "Password mismatch"
    }
  }

}

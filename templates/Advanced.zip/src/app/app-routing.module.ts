import { NgModule } from '@angular/core';
import { RouterModule, ROUTES, Routes } from '@angular/router';
import { SharedComponent } from './components/shared/shared.component';
import { PageNotFoundComponent } from './shared/fallback/page-not-found/page-not-found.component';
import { AuthGuard } from './shared/guards/auth.guard';
import { ConfigResolver } from './shared/resolver/config-data.resolver';
import { Global } from './global';
import { NoChangeDataResolver } from './shared/resolver/no-change-data.resolver';

const standardRoutes: Routes = [
  {
    path: '', loadChildren: () => import('./home/home.module').then(m => m.HomeModule),
    resolve: {
      configData: ConfigResolver,
      noChangeData: NoChangeDataResolver
    }
  },
  {
    path: 'home', loadChildren: () => import('./home/home.module').then(m => m.HomeModule),
    resolve: {
      configData: ConfigResolver,
      noChangeData: NoChangeDataResolver
    }
  },
  {
    path: 'offers', loadChildren: () => import('./offers/offers.module').then(m => m.OffersModule),
    resolve: {
      configData: ConfigResolver,
      noChangeData: NoChangeDataResolver
    }
  },
  {
    path: 'login', loadChildren: () => import('./login/login.module').then(m => m.LoginModule),
    resolve: {
      configData: ConfigResolver,
      noChangeData: NoChangeDataResolver
    }
  },
  {
    path: 'register', loadChildren: () => import('./register/register.module').then(m => m.RegisterModule),    
    resolve: {
      configData: ConfigResolver,
      noChangeData: NoChangeDataResolver
    }
  },
  {
    path: 'category/:name/:id', loadChildren: () => import('./view-products/view-products.module').then(m => m.ViewProductsModule),
  },
  {
    path: 'category/:id', loadChildren: () => import('./view-products/view-products.module').then(m => m.ViewProductsModule),
  },
  {
    path: 'product/:name/:id', loadChildren: () => import('./product-details/product-details.module').then(m => m.ProductDetailsModule),
  },
  {
    path: 'product/:id', loadChildren: () => import('./product-details/product-details.module').then(m => m.ProductDetailsModule),
  },
  {
    path: 'wishlist', loadChildren: () => import('./wishlist/wishlist.module').then(m => m.WishlistModule),
    canActivate: [AuthGuard],
    data: {
      seo: {
        title: 'Wishlist Page',
        metaTags: [
          { name: 'description', content: 'Wishlist Page' },
          { property: 'og:title', content: 'Wishlist Page' },
          { proprety: 'og:description', content: 'Wishlist Page' },
          { property: 'og:url', content: 'wishlist' },
        ]
      }
    }
  },
  {
    path: 'categories', loadChildren: () => import('./categories/categories.module').then(m => m.CategoriesModule),
    data: {
      seo: {
        title: 'Categories Page',
        metaTags: [
          { name: 'description', content: 'Categories Page' },
          { property: 'og:title', content: 'Categories Page' },
          { proprety: 'og:description', content: 'Categories Page' },
          { property: 'og:url', content: 'Categories' },
        ]
      }
    }
  },
  {
    path: 'compare', loadChildren: () => import('./compare/compare.module').then(m => m.CompareModule),
    data: {
      seo: {
        title: 'Compare Page',
        metaTags: [
          { name: 'description', content: 'Compare Page' },
          { property: 'og:title', content: 'Compare Page' },
          { proprety: 'og:description', content: 'Compare Page' },
          { property: 'og:url', content: 'compare' },
        ]
      }
    }
  },
  {
    path: 'cart', loadChildren: () => import('./cart/cart.module').then(m => m.CartModule),
    data: {
      seo: {
        title: 'Cart Page',
        metaTags: [
          { name: 'description', content: 'Cart Page' },
          { property: 'og:title', content: 'Cart Page' },
          { proprety: 'og:description', content: 'Cart Page' },
          { property: 'og:url', content: 'cart' },
        ]
      }
    }
  },
  {
    path: 'checkout', loadChildren: () => import('./checkout/checkout.module').then(m => m.CheckoutModule),
    data: {
      seo: {
        title: 'Checkout Page',
        metaTags: [
          { name: 'description', content: 'Checkout Page' },
          { property: 'og:title', content: 'Checkout Page' },
          { proprety: 'og:description', content: 'Checkout Page' },
          { property: 'og:url', content: 'checkout' },
        ]
      }
    }
  },
  {
    path: 'tracking-orders', loadChildren: () => import('./tracking-orders/tracking-orders.module').then(m => m.TrackingOrdersModule),
    canActivate: [AuthGuard],
    data: {
      seo: {
        title: 'Tracking Orders Page',
        metaTags: [
          { name: 'description', content: 'Tracking Orders Page' },
          { property: 'og:title', content: 'Tracking Orders Page' },
          { proprety: 'og:description', content: 'Tracking Orders Page' },
          { property: 'og:url', content: 'tracking-orders' },
        ]
      }
    }
  },
  {
    path: 'my-account', loadChildren: () => import('./my-account/my-account.module').then(m => m.MyAccountModule),
    canActivate: [AuthGuard],
    data: {
      seo: {
        title: 'My Account Page',
        metaTags: [
          { name: 'description', content: 'My Account Page' },
          { property: 'og:title', content: 'My Account Page' },
          { proprety: 'og:description', content: 'My Account Page' },
          { property: 'og:url', content: 'my-account' },
        ]
      }
    }
  },
  {
    path: 'change-password', loadChildren: () => import('./change-password/change-password.module').then(m => m.ChangePasswordModule),
    canActivate: [AuthGuard],
    data: {
      seo: {
        title: 'Change Password Page',
        metaTags: [
          { name: 'description', content: 'Change Password Page' },
          { property: 'og:title', content: 'Change Password Page' },
          { proprety: 'og:description', content: 'Change Password Page' },
          { property: 'og:url', content: 'change-password' },
        ]
      }
    }
  },
  {
    path: 'forgot-password', loadChildren: () => import('./forgot-password/forgot-password.module').then(m => m.ForgotPasswordModule),
    data: {
      seo: {
        title: 'Forgot Password Page',
        metaTags: [
          { name: 'description', content: 'Forgot Password Page' },
          { property: 'og:title', content: 'Forgot Password Page' },
          { proprety: 'og:description', content: 'Forgot Password Page' },
          { property: 'og:url', content: 'forgot-password' },
        ]
      }
    }
  },
  {
    path: 'confirm-order', loadChildren: () => import('./confirm-order/confirm-order.module').then(m => m.ConfirmOrderModule),
    canActivate: [AuthGuard],
    data: {
      seo: {
        title: 'Confirm Order Page',
        metaTags: [
          { name: 'description', content: 'Confirm Order Page' },
          { property: 'og:title', content: 'Confirm Order Page' },
          { proprety: 'og:description', content: 'Confirm Order Page' },
          { property: 'og:url', content: 'confirm-order' },
        ]
      }
    }
  },
  {
    path: 'search', loadChildren: () => import('./search/search.module').then(m => m.SearchModule),
    data: {
      seo: {
        title: 'Search Page',
        metaTags: [
          { name: 'description', content: 'Search Page' },
          { property: 'og:title', content: 'Search Page' },
          { proprety: 'og:description', content: 'Search Page' },
          { property: 'og:url', content: 'search' },
        ]
      }
    }
  },
  {
    path: 'reset-password', loadChildren: () => import('./reset-password/reset-password.module').then(m => m.ResetPasswordModule),
    data: {
      seo: {
        title: 'Reset Password Page',
        metaTags: [
          { name: 'description', content: 'Reset Password Page' },
          { property: 'og:title', content: 'Reset Password Page' },
          { proprety: 'og:description', content: 'Reset Password Page' },
          { property: 'og:url', content: 'reset-password' },
        ]
      }
    }
  },
  {
    path: '404',
    component: PageNotFoundComponent
  },
  {
    path: '**',
    redirectTo: '404'
  }
]

@NgModule({
  imports: [RouterModule.forRoot([])],
  exports: [RouterModule],
  providers: [
    {
      provide: ROUTES,
      useFactory: (global: Global) => {
        let routes: Routes = [];
        let configPages: any = [];
        let currentRoute: any = ''
        currentRoute = window.location.pathname;
        if (currentRoute.charAt(0) === "/") {
          currentRoute = currentRoute.substring(1);
        }
        if (global.configPages && global.configPages.length > 0) {
          configPages = global.configPages
        }
        if (configPages && configPages.length > 0) {
          for (let i = 0; i < configPages.length; i++) {
            if (currentRoute != '' && configPages[i] != currentRoute) {
              global.isDynamicPagesNotfound = true;
            }
            else {
              routes.push({ path: configPages[i], component:  SharedComponent  })
            }
          }
        }
        return [
          ...routes,
          ...standardRoutes
        ];
      },
      deps: [Global],
      multi: true
    }
  ]
})
export class AppRoutingModule { }

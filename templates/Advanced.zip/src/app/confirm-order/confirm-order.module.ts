import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ConfirmOrderRoutingModule } from './confirm-order-routing.module';
import { ConfirmOrderComponent } from './confirm-order.component';
import { TranslateModule } from '@ngx-translate/core';
import { NgxSpinnerModule } from 'ngx-spinner';


@NgModule({
  declarations: [ConfirmOrderComponent],
  imports: [
    CommonModule,
    ConfirmOrderRoutingModule,
    TranslateModule,
    NgxSpinnerModule
  ]
})
export class ConfirmOrderModule { }

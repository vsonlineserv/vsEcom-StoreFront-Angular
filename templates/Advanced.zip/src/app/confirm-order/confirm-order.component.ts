import { Component, OnInit } from '@angular/core';
import { CartService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../global';
import { ActivatedRoute } from '@angular/router';
import { GlobalService } from '../service/global.service';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-confirm-order',
  templateUrl: './confirm-order.component.html',
  styleUrls: ['./confirm-order.component.css']
})
export class ConfirmOrderComponent implements OnInit {

  orderid: any;
  orderConfirmation: any = [];
  data: any = '';
  deliveryDetails: any = '';
  deliveryOption: any;
  totalShipping: any = 0;

  constructor(public global: Global, private cartService: CartService, private route: ActivatedRoute,
    public globalService: GlobalService, private spinner: NgxSpinnerService) {
    route.queryParams.subscribe(params => {
      let OrderId = params['orderId'];
      this.orderid = OrderId;
      this.getOrderConfirmationDetails();
    });
  }

  ngOnInit() {
    this.getShippingDetails();
  }

 getOrderConfirmationDetails() {
    this.spinner.show();
    this.cartService.GetOrderConfirmationDetails(this.orderid, this.global.userName)
      .subscribe((response: any) => {
        this.spinner.hide();
        if (response) {
          this.orderConfirmation = response;
        }
      },error => {
        this.spinner.hide();
      });
  }

  getShippingDetails() {
    this.spinner.show();
    this.cartService.getShippingType().subscribe((response: any) => {
      this.spinner.hide();
      this.data = response;
      if (this.data != '') {
        this.spinner.show();
        this.cartService.getShippingDetails(this.data).subscribe((response: any) => {
          this.spinner.hide();
          if (response.rate != '') {
            this.totalShipping = Number(response.rate);
            this.deliveryDetails = response;
          }
        }, error => {
          this.spinner.hide();
        });
      }
    }, error => {
      this.spinner.hide();
    });
    this.globalService.CalculateCartTotal();
  }

  getISTDate(orderDateUtc) {
    let IST = new Date(orderDateUtc + 'Z'); // Clone UTC Timestamp
    return IST;
  }
  
}

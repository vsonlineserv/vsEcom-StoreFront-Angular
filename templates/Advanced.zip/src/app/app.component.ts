import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Observable, startWith, debounceTime, distinctUntilChanged, switchMap, map, filter, mergeMap } from 'rxjs';
import { GlobalService } from './service/global.service';
import { Global } from './global';
import { Title, Meta } from '@angular/platform-browser';
import { LandingService, WishlistService } from '@vsecom/vs-ecom-storefront-services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {

  mainMenu: any = [];
  mainMenuMobile: any = [];
  showFloatingMenuIcon: boolean;
  showFloatingCloseIcon: boolean;
  showfloatingMenubar: boolean;
  showfloatingSearchbar: boolean;
  search: any = '';
  searchRequests: any = [];
  searchProductList: any = [];
  searchField = new FormControl();
  searchList: Observable<any>;
  searchValue: any;
  footer: any;
  searchbar: boolean; 
  matExpantValue: any = '';
  comparisonlist: any = [];
  cartlist: any = [];
  storeLogo: any;

  constructor(public global: Global, private landingService: LandingService, private httpClient: HttpClient, private activatedRoute: ActivatedRoute, private title: Title, private meta: Meta, private wishlistService: WishlistService,
    public translateService: TranslateService, public globalService: GlobalService, private router: Router, @Inject(PLATFORM_ID) private platformId: object, @Inject(DOCUMENT) private document: Document) {
    translateService.use('en-us');
    this.searchList = this.searchField.valueChanges.pipe(
      startWith(''),
      debounceTime(400),
      distinctUntilChanged(),
      switchMap((value: any) => {
        return this.filter(value || '')
      })
    )
  }

  ngOnInit() {
    // Initial App Load
    this.initApplication();
    // For changing all pages meta information
    this.changeMetaInformation();
  }

  changeMetaInformation() {
    this.router.events.pipe(filter(e => e instanceof NavigationEnd), map(e => this.activatedRoute), map((route) => {
      while (route.firstChild) route = route.firstChild;
      return route;
    }), filter((route) => route.outlet === 'primary'), mergeMap((route) => route.data)).subscribe(data => {
      if (data['seo']) {
        let seoData = data['seo'];
        this.globalService.updateTitle(seoData['title']);
        this.globalService.updateMetaTags(seoData['metaTags']);
      }
    })
  }

  initApplication() {
    this.getScreenSize();
    this.getMenu();
    this.getUserWishlistCount();
    if (isPlatformBrowser(this.platformId)) {
      this.global.configData = JSON.parse(localStorage.getItem('configData'));
      this.global.comparisonlist = JSON.parse(localStorage.getItem('comparisonlist'));
      this.global.cartlist = JSON.parse(localStorage.getItem('cartlist'));
      if(this.global.comparisonlist == null || this.global.comparisonlist == undefined){
        this.global.comparisonlist = [];
      }
      if(this.global.cartlist == null || this.global.cartlist == undefined){
        this.global.cartlist = [];
      }
      if (this.global.cartlist) {
        this.global.cartCount = this.global.cartlist.length;
      }
      if(this.global.comparisonlist){
        this.global.compareListCount = this.global.comparisonlist.length;
      }
    }
    this.showFloatingMenuIcon = true;
  }

  getMenu() {
    this.landingService.GetMainMenu().subscribe((response: any) => {
      this.mainMenu = response;
    })
  }

  getScreenSize(event?) {
    if (isPlatformBrowser(this.platformId)) {
      this.footer = document.getElementById('footer').offsetHeight;
      let routerOutlets = document.getElementById('router');
      let footer = document.getElementById('footer');
      routerOutlets.style.paddingBottom = this.footer + 'px';
      footer.style.height = this.footer + 'px';
    }
  }

  getUserWishlistCount(){
    if (this.global.userName && this.global.userName.length > 0) {
      this.wishlistService.GetUserWishlistCount(this.global.userName).subscribe((response: any) => {
        this.global.wishListCount = response;
      });
    }
  }

  showfloatingMenuIcon() {
    this.showFloatingCloseIcon = true;
    this.showFloatingMenuIcon = false;
    this.showfloatingMenubar = true;

  }

  showfloatingCloseIcon() {
    this.showFloatingMenuIcon = true;
    this.showFloatingCloseIcon = false;
    this.showfloatingMenubar = false;
  }

  showSearch() {
    this.showfloatingSearchbar = true;
  }

  closeSearch() {
    this.showfloatingSearchbar = false;
  }

  searchCatalogue(value) {
    if (value.productId) {
      this.router.navigate(['product/' + value.permaLink + '/' + value.productId]);
      this.searchValue = '';
      this.showfloatingSearchbar = false;
    }
    else {
      this.router.navigate(['/search'], { queryParams: { search: value } });
    }
  }

  filter(val: any): Observable<any[]> {
    if(val == ""){
      val = null
    }
    return this.landingService.GetSearchProductList(val).pipe(map((response: any) => response.filter((option: any) => {
      return option;
    }))
    )
  }

  navigateLoginPage() {
    this.router.navigate(['login']);
  }

  navigateCartPage() {
    this.router.navigate(['cart']);
  }

  navigateProductsPage(e: any) {
    if (e.event.subCategoryId) {
      this.router.navigate(['category/' + e.event.permaLink + '/' + e.event.subCategoryId]);
    }
    else {
      this.router.navigate(['category/' + e.event.permaLink + '/' + e.event.parentCategoryId]);
    }
  }

  navigateOffersPage() {
    this.router.navigate(['offers'])
  }

  navigateHomePage() {
    this.router.navigate([''])
  }

  navigateAccountPage() {
    this.router.navigate(['my-account']);
  }

  navigateOrderTrackingPage() {
    this.router.navigate(['tracking-orders']);
  }

  navigateChangePasswordPage() {
    this.router.navigate(['change-password']);
  }

  navigateLogout() {
    this.globalService.Logout();
  }

  navigatingRegister() {
    this.router.navigate(['/register']);
  }

  navigateMobileOffersPage() {
    this.router.navigate(['offers']);
    this.showFloatingMenuIcon = true;
    this.showFloatingCloseIcon = false;
    this.showfloatingMenubar = false;
  }

  navigateMobileHomePage() {
    this.router.navigate(['home']);
    this.showFloatingMenuIcon = true;
    this.showFloatingCloseIcon = false;
    this.showfloatingMenubar = false;
  }

  navigateSearchPage() {
    this.router.navigate(['search']);
  }

  showSearchBar(){
    this.searchbar = true;
  }

  openfloatingMenu() {
    var body = document.body;
    document.getElementById('mobile-menu-overlay').classList.add('active');
    body.classList.add('no-overflow');
  }

  closeMobileMenu() {
    document.getElementById('mobile-menu-overlay').classList.remove('active');
  }

  expandCategory(expandId: any) {
    if (expandId == this.matExpantValue) {
      this.matExpantValue = '';
    } else {
      this.matExpantValue = expandId;
    }
  }
  
  navigateWishlistPage(){
    this.router.navigate(['wishlist'])
  }

  navigateComparePage(){
    this.router.navigate(['compare'])
  }
  
  navigateCheckoutPage() {
    this.router.navigate(['checkout'])
  }

  removeProductFromComparison(event) {
    let removeProduct = this.createComparisonListProduct(event.product);
    var index = this.global.comparisonlist.findIndex(compareList => compareList.productId == removeProduct.productId);
    if (index > -1) {
      this.global.comparisonlist.splice(index, 1);
      if (isPlatformBrowser(this.platformId)) {
        localStorage.setItem('comparisonlist', JSON.stringify(this.global.comparisonlist));
      }
    this.updateComparisonProductIdList();
    }
    event.stopPropagation();
  }

  createComparisonListProduct(product) {
    let removeComparisonProduct : any= {};
    removeComparisonProduct.productId = product.productId;
    removeComparisonProduct.name = product.name;
    removeComparisonProduct.pictureName = product.pictureName;
    removeComparisonProduct.specialPrice = product.specialPrice;
    removeComparisonProduct.price = product.price;
    return removeComparisonProduct;
  }

  updateComparisonProductIdList() {
    this.global.comparisonlistProductId.splice(0, this.global.comparisonlistProductId.length);
    for (var i = 0; i < this.global.comparisonlist.length; i++) {
      this.global.comparisonlistProductId.push(this.global.comparisonlist[i].productId);
    }
    if (this.global.comparisonlist) {
      this.global.compareListCount = this.global.comparisonlist.length;
    }

  }

  shopChange(){
    this.router.navigate(['categories'])
  }

  aboutChange(){
    this.router.navigate(['About'])
  }

  blogChange(){
    this.router.navigate(['Blog'])
  }
  
  contactChange(){
    this.router.navigate(['Contact'])
  }

  navigateSharedChangeEvent(event) {
    window.scrollTo(0,0);
    this.router.navigate([event.event]);
  }
}

import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { ProductService, WishlistService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../global';
import { GlobalService } from '../service/global.service';
import { TranslateService } from '@ngx-translate/core';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-wishlist',
  templateUrl: './wishlist.component.html',
  styleUrls: ['./wishlist.component.css']
})
export class WishlistComponent implements OnInit {

  offerTitleImg: boolean = false;
  lat = 13.058312;
  lng = 80.21195;
  searchRadius = 5;
  itemsPerPage = 50;
  wishlist: any = [];
  showNoProducts: boolean = false;
 
   
  constructor(private productService: ProductService, public global: Global, public globalService: GlobalService, private translateService: TranslateService,
    private wishlistService: WishlistService, @Inject(PLATFORM_ID) private platformId: object, private router: Router) {
    translateService.use('en-us');
  }

  async ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.global.configData = JSON.parse(localStorage.getItem('configData'))
    }
    this.getWishlistProducts();
  }

  getWishlistProducts(){
    this.wishlistService.GetWishlistProducts(this.lat, this.lng, this.searchRadius, 1, this.itemsPerPage).subscribe((data) => {
     this.wishlist = data;
     this.wishlist.totalCount = this.wishlist[0].totalCount;
     this.displayNoProducts();
    },
    error => {
      this.displayNoProducts();
    });
  }

  removeProductWishlist(value){
    let productId = value.event.productId;
    this.wishlistService.RemoveUserWishlist(productId,this.global.userName).subscribe((data) => {
    this.wishlist = data;
    this.getWishlistProducts()
    value.event.flagWishlist = false;
    this.global.wishListCount = this.wishlist.length;
    });
  }

  displayNoProducts() {
    if (this.wishlist && this.wishlist.length == 0) {
      this.showNoProducts = true;
    }
  }

  navigateHomePage(){
    if (isPlatformBrowser(this.platformId)) {
      window.scrollTo(0,0);
      this.router.navigate(['home'])
    }
  }

}

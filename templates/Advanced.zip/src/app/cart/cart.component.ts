import { isPlatformBrowser } from '@angular/common';
import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { Global } from '../global';
import { CartService } from '@vsecom/vs-ecom-storefront-services';
import { GlobalService } from '../service/global.service';
import { Router } from '@angular/router';

@Component({
  selector: 'app-cart',
  templateUrl: './cart.component.html',
  styleUrls: ['./cart.component.css']
})
export class CartComponent implements OnInit {

  deliveryDetails: any = [];
  totalShipping: any = 0;
  navigatehomepage:boolean=true;

  constructor(private translateService: TranslateService, public global: Global, public globalService: GlobalService, private cartService: CartService,
    private router: Router, @Inject(PLATFORM_ID) private platformId: object) {
    translateService.use('en-us');
  }

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.global.cartlist = JSON.parse(localStorage.getItem('cartlist'));
      this.global.cartTotal = Number(localStorage.getItem('cartTotal'));
      this.global.currency = localStorage.getItem('currency');
      this.global.taxType = localStorage.getItem('taxType');
    }
    if (!this.global.cartlist || this.global.cartlist == 0) {
      this.global.vsShowEmptyCart = true;
    }
    else {
      this.global.vsShowEmptyCart = false;
    }
    this.getShippingCharges()
  }

  getShippingCharges() {
    this.cartService.getShippingType().subscribe((response: any) => {
      if (response != '') {
        this.cartService.getShippingDetails(response).subscribe((response: any) => {
          if (response.rate != '') {
            this.totalShipping = Number(response.rate);
            this.deliveryDetails = response;
          }
        });
      }
    });
    this.globalService.CalculateCartTotal();
  }

  navigateCheckoutPage() {
    this.router.navigate(['checkout'])
  }
  navigateHomePage(){
    this.router.navigate(['home'])
  }
  gotohome(){
    if(this.navigatehomepage){
      setTimeout(function()
      { window.location.assign('/home')
     }, 3000)
    }
  } 

}

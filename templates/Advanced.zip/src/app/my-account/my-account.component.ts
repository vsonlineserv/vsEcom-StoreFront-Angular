import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { TranslateService } from '@ngx-translate/core';
import { UserActionService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../global';
import { isPlatformBrowser, ViewportScroller } from '@angular/common';
import { GlobalService } from '../service/global.service';
import { FormGroup, FormControl, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { NgxSpinnerService } from 'ngx-spinner';


@Component({
  selector: 'app-my-account',
  templateUrl: './my-account.component.html',
  styleUrls: ['./my-account.component.css']
})
export class MyAccountComponent implements OnInit {
  user: any = {};
  myaccForm: FormGroup;
  submitted: boolean;
  myaccountForm: boolean;
  savedSuccessfully: boolean;
  message: any = '';

  constructor(private scroller: ViewportScroller,private userActionService: UserActionService,private globalService:GlobalService,private spinner: NgxSpinnerService, private translateService: TranslateService, private router: Router,
    @Inject(PLATFORM_ID) private platformId: object, public global: Global) {
    translateService.use('en-us');
    this.myaccForm = new FormGroup({
      FirstName: new FormControl('', [Validators.required]),
      LastName: new FormControl(''),
      Email: new FormControl('', [Validators.required, Validators.email]),
      PhoneNumber1: new FormControl('', [Validators.required, Validators.minLength(6), Validators.maxLength(14)]),
      UserId: new FormControl(''),
    });
  }

  async ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.global.userName = localStorage.getItem('userName')
    }
    this.getMyDetails();
  }

  getMyDetails() {
    this.spinner.show();
    this.userActionService.GetUserDetails(this.global.userName).subscribe((response: any) => {
    this.spinner.hide();
      this.user.Email = response.email;
      this.user.PhoneNumber1 = response.phoneNumber1;
      this.user.FirstName = response.firstName;
      this.user.LastName = response.lastName;
      this.user.UserID = response.userId;
      if (response != null) {
        this.myaccForm.patchValue({
          FirstName: response.firstName,
          LastName:response.lastName,
          Email: response.email,
          PhoneNumber1: response.phoneNumber1,
          UserId: response.userId,
        });
      }
    },
    error => {
      this.spinner.hide();
    });
  }
  save() {
    this.submitted = true;
    if (!this.myaccForm.valid) {
      return;
    }
    if (this.myaccForm.value) {
      this.userActionService.UpdateUserDetails(this.myaccForm.value).subscribe((response) => {
        if (response) {
          if ( this.user.Email != this.myaccForm.value.Email) {
               this.globalService.Logout();
          }
          else {
            this.myaccountForm = false;
            this.savedSuccessfully = true;
            this.message = response;
            setTimeout(() => {
              if (isPlatformBrowser(this.platformId)) {
                this.message = '';
                this.getMyDetails();
              }
            }, 2000);
          }
        }
      },
        err => { 
          this.myaccountForm = false;
          this.savedSuccessfully = false;
          this.message = err.error;
          setTimeout(() => {
            if (isPlatformBrowser(this.platformId)) {
              this.message = '';
            }
          }, 2000);
        });
    }
  }



  reset() {
    this.myaccForm.reset();
  }

  closeform() {
    this.myaccountForm = false;
  }

  openform() {
    this.myaccountForm = true;
    setTimeout(() => {
      this.scroller.scrollToAnchor("my-account-form");
      document.getElementById("Name").focus();
    }, 200);
  }


  goBack() {
    this.router.navigate([''])
  }

}

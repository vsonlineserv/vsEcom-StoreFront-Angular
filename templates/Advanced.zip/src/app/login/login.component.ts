import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { FormBuilder, FormControl, FormGroup, Validators } from '@angular/forms';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { Global } from '../global';
import { AuthService, WishlistService } from '@vsecom/vs-ecom-storefront-services';
import { CartService } from '@vsecom/vs-ecom-storefront-services';
import { GlobalService } from '../service/global.service';
import { UserActionService } from '@vsecom/vs-ecom-storefront-services';
import { TranslateService } from '@ngx-translate/core';
import { isPlatformBrowser } from '@angular/common';
@Component({
  selector: 'app-login',
  templateUrl: './login.component.html',
  styleUrls: ['./login.component.css']
})
export class LoginComponent implements OnInit {

  message: any;
  loginForm: FormGroup;
  savedSuccessfully: boolean = false;
  user: any = {};
  curUser: any = {};
  googleAuthToken: any = "";
  googleUser: any = {};

  constructor(private titleService: Title, private meta: Meta, public global: Global, private globalService: GlobalService, private authService: AuthService, private activatedRoute: ActivatedRoute,
    private cartService: CartService, private userActionService: UserActionService, private formBuilder: FormBuilder, private router: Router, private translate: TranslateService,
    private wishlistService: WishlistService, @Inject(PLATFORM_ID) private platformId: object) {
    translate.use('en-us');
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(data => {
      this.globalService.updataDynamicSEO(data['noChangeData']['metaTags']['Login']);
      this.globalService.GetLoggedInUserToken();
      if (isPlatformBrowser(this.platformId)) {
        this.global.userName = localStorage.getItem('userName');
        this.loadUserDefaults();
      }
    });
  }

  login(event: any) {
    this.authService.Login(event.loginData).subscribe((response) => {
      let tokenObj: any = {};
      Object.assign(tokenObj, response)
      this.globalService.SetLoggedInUserToken(tokenObj);
      this.global.flagLoggedIn = true;
      this.global.userName = event.loginData.UserName;
      this.global.curUserDisplayName = '';
      this.loadUserDefaults();
      this.getUserWishlistCount();
    }, err => {
      this.message = err.error;
      this.global.flagLoggedIn = false;
      this.globalService.ClearCookieStore();
    });
  }

  loadUserDefaults() {
    if (this.global.userName && this.global.userName.length > 0) {
      this.userActionService.GetUserDetails(this.global.userName).subscribe((response: any) => {
        this.curUser.Email = response.email;
        this.curUser.PhoneNumber1 = response.phoneNumber1;
        this.curUser.FirstName = response.firstName;
        this.curUser.LastName = response.lastName;
        this.global.curUserDisplayName = response.firstName;
        this.router.navigate(['home'])
        if (response.Email || response.phoneNumber1) {
          if (isPlatformBrowser(this.platformId)) {
            localStorage.setItem('flagLoggedIn', this.global.flagLoggedIn);
            localStorage.setItem('userName', this.global.userName);
            localStorage.setItem('curUserDisplayName', this.global.curUserDisplayName);
          }
        }
        if (this.global.cartlist && this.global.cartlist.length > 0) {
          this.cartService.AddShoppingCartItemList(this.global.cartlist, this.global.userName)
            .subscribe((response: any) => {
              this.getShoppingCartItems();
            });
        }
        else {
          this.getShoppingCartItems();
        }
      });
    }
    else {
      return;
    }
  }

  getShoppingCartItems() {
    this.cartService.GetShoppingCartItems(this.global.userName).subscribe((response: any) => {
      if (response && response.length > 0) {
        this.global.cartlist = [];
        for (var i = 0; i < response.length; i++) {
          let addtoCartProduct = this.createCartListProductObjectFromList(response[i]);

          this.global.cartlist.push(addtoCartProduct);
        }
        if (this.global.cartlist && this.global.cartlist.length > 0) {
          if (isPlatformBrowser(this.platformId)) {
            localStorage.setItem('cartlist', JSON.stringify(this.global.cartlist));
          }
        }
        else {
          if (isPlatformBrowser(this.platformId)) {
            this.global.cartlist = JSON.parse(localStorage.getItem('cartlist'));
          }
        }
      }
      this.globalService.CalculateCartTotal();
    });
  }

  createCartListProductObjectFromList(product: any) {
    if (product.productId > 0) {
      let cart: any = {};
      cart.ProductId = product.productId;
      cart.Name = product.name;
      cart.PictureName = product.pictureName;
      cart.SpecialPrice = product.specialPrice;
      cart.Price = product.price;
      cart.Branch = product.branch;
      cart.BranchId = product.branchId;
      cart.StoresCount = product.storesCount;
      cart.FlagWishlist = product.flagWishlist;
      cart.Quantity = product.quantity;
      cart.SelectedSize = product.selectedSize;
      cart.AdditionalShippingCharge = product.additionalShippingCharge;
      cart.TotalAdditionalShippingCharge = product.additionalShippingCharge * cart.Quantity;
      cart.SubTotal = (cart.SpecialPrice * cart.Quantity);
      cart.SubTotalWithShipping = (cart.SpecialPrice * cart.Quantity) + cart.TotalAdditionalShippingCharge;
      return cart;
    }
  }

  navigatingForgotPassword() {
    this.router.navigate(['/forgot-password']);
  }

  navigatingRegister() {
    this.router.navigate(['/register']);
  }

  getUserWishlistCount() {
    if (this.global.userName && this.global.userName.length > 0) {
      this.wishlistService.GetUserWishlistCount(this.global.userName).subscribe((response: any) => {
        this.global.wishListCount = response;
      });
    }
  }

}

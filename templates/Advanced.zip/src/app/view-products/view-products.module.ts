import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ViewProductsRoutingModule } from './view-products-routing.module';
import { ViewProductsComponent } from './view-products.component';
import { TranslateModule } from '@ngx-translate/core';
import { MatSelectModule } from '@angular/material/select';
import { MatFormFieldModule } from '@angular/material/form-field';
import { MatMenuModule } from '@angular/material/menu';
import { VssuiteEcomModule } from '@vssuite/vs-angular-ecom-components';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
  declarations: [ViewProductsComponent],
  imports: [
    CommonModule,
    ViewProductsRoutingModule,
    TranslateModule,
    MatSelectModule,
    MatFormFieldModule,
    MatMenuModule,
    VssuiteEcomModule,
    NgxSpinnerModule
  ]
})
export class ViewProductsModule { }
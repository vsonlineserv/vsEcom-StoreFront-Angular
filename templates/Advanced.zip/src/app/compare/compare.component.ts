import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { ProductService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../global';
import { GlobalService } from '../service/global.service';
import { TranslateService } from '@ngx-translate/core';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-compare',
  templateUrl: './compare.component.html',
  styleUrls: ['./compare.component.css']
})
export class CompareComponent implements OnInit {

  comparisonProductlist : any =[];
  productComparisonResult: any = [];
  productDetailedComparisonResult: any = [];
  ids: any;
  productId: any;
  showNoProducts: boolean = false;

  constructor(private productService: ProductService, public global: Global, public globalService: GlobalService, private translateService: TranslateService,
    @Inject(PLATFORM_ID) private platformId: object, private router: Router) {
    translateService.use('en-us');
  }

  async ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.global.configData = JSON.parse(localStorage.getItem('configData'));
      this.global.comparisonlist = JSON.parse(localStorage.getItem('comparisonlist'));
    }
    this.compareProduct()
  }

  compareProduct() {
    this.comparisonProductlist = this.global.comparisonlist;
    var productIds = [];
    for(var i = 0; i < this.comparisonProductlist.length; i++)
    {
        productIds.push(this.comparisonProductlist[i].productId);
    }
    this.productService.CompareProduct(productIds).subscribe((response: any) => {
      Object.assign(this.productComparisonResult, response);
    });
    this.productService.CompareProductDetailedSpecification(productIds).subscribe((response:any) => {
      Object.assign(this.productDetailedComparisonResult, response);
    });
    this.displayNoProducts();
  }

  displayNoProducts() {
    if (this.comparisonProductlist && this.comparisonProductlist.length == 0) {
      this.showNoProducts = true;
    }
  }

  navigateHomePage(){
    if (isPlatformBrowser(this.platformId)) {
      window.scrollTo(0,0);
      this.router.navigate(['home'])
    }
  }

}

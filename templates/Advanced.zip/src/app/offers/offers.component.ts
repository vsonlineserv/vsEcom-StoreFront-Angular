import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { ProductService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../global';
import { GlobalService } from '../service/global.service';
import { TranslateService } from '@ngx-translate/core';
import { isPlatformBrowser } from '@angular/common';
import { ActivatedRoute, Router } from '@angular/router';

@Component({
  selector: 'app-offers',
  templateUrl: './offers.component.html',
  styleUrls: ['./offers.component.css']
})
export class OffersComponent implements OnInit {

  offerProducts: any = [];
  messageOffers: any = '';
  offerTitleImg: boolean = false;
  showNoProducts: boolean = false;

  constructor(private productService: ProductService, public global: Global, public globalService: GlobalService, private translateService: TranslateService,
    @Inject(PLATFORM_ID) private platformId: object, private activatedRoute: ActivatedRoute, private router: Router) {
    translateService.use('en-us');
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(data => {
      this.globalService.updataDynamicSEO(data['noChangeData']['metaTags']['Offers']);
      if (data) {
        this.global.configData = data['configData']['elements']
      }
      this.getAllOffers();
    });
  }

  getAllOffers() {
    this.productService.GetAllOffers().subscribe((response: any) => {
      this.offerProducts = response;
      if (this.offerProducts && this.offerProducts.length == 0) {
        this.messageOffers = 'No Offers in selected Area.';
        this.showNoProducts = true;
      }
    });
  }

  navigateHomePage(){
    if (isPlatformBrowser(this.platformId)) {
      window.scrollTo(0,0);
      this.router.navigate(['home'])
    }
  }

}

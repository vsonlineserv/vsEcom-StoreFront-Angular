import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { AuthService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../global';
import { GlobalService } from '../service/global.service';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { CartService } from '@vsecom/vs-ecom-storefront-services';
import { UserActionService } from '@vsecom/vs-ecom-storefront-services';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-register',
  templateUrl: './register.component.html',
  styleUrls: ['./register.component.css']
})
export class RegisterComponent implements OnInit {

  registerForm: FormGroup;
  message: any = '';
  registerData: any = {};

  constructor(public global: Global, private authService: AuthService, private translateService: TranslateService, @Inject(PLATFORM_ID) private platformId: object,
    private router: Router, private globalService: GlobalService, private userActionService: UserActionService, private cartService: CartService, private activatedRoute: ActivatedRoute) {
    translateService.use('en-us');
  }

  ngOnInit() {
    this.activatedRoute.data.subscribe(data => {
      this.globalService.updataDynamicSEO(data['noChangeData']['metaTags']['Register']);
    });
  }

  register(event: any) {
    this.registerData = event.registerData;
    this.authService.RegisterUser(this.registerData).subscribe((response: any) => {
      this.login();
    }, error => {
      this.message = error.error;
    });
  }

  login() {
    if (this.registerData.Email && this.registerData.PhoneNumber1) {
      this.registerData.UserName = this.registerData.Email;
    }
    if (this.registerData.PhoneNumber1 && (this.registerData.Email == undefined || this.registerData.Email == '' || this.registerData.Email == null)) {
      this.registerData.UserName = this.registerData.PhoneNumber1;
    }
    this.authService.Login(this.registerData).subscribe((response) => {
      let tokenObj: any = {};
      Object.assign(tokenObj, response)
      this.globalService.SetLoggedInUserToken(tokenObj);
      this.global.flagLoggedIn = true;
      if (this.registerData.Email != '' && this.registerData.Email != null && this.registerData.Email != undefined) {
        this.registerData.Username = this.registerData.Email;
      } else {
        this.registerData.Username = this.registerData.PhoneNumber1;
      }
      this.global.userName = this.registerData.Username;
      if (isPlatformBrowser(this.platformId)) {
        localStorage.setItem('userName', this.registerData.Username);
      }
      this.global.curUserDisplayName = '';
      this.router.navigate(['/login']);
    }, err => {
      this.message = err.error;
      this.global.flagLoggedIn = false;
      this.globalService.ClearCookieStore();
    });
  }

}

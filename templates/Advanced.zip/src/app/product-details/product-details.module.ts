import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { ProductDetailsRoutingModule } from './product-details-routing.module';
import { ProductDetailsComponent } from './product-details.component';
import { TranslateModule } from '@ngx-translate/core';
import { MatIconModule } from '@angular/material/icon';
import { MatDialogModule } from '@angular/material/dialog';
import { MatFormFieldModule } from '@angular/material/form-field';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { CheckAvailabilityComponent } from '../components/check-availability/check-availability.component';
import { MatInputModule } from '@angular/material/input';
import { VssuiteEcomModule } from '@vssuite/vs-angular-ecom-components';
import { NgxImageZoomModule } from 'ngx-image-zoom';
import { NgxMaterialRatingModule } from 'ngx-material-rating';
import { UserLoginComponent } from '../components/user-login/user-login.component';
import { NgxSpinnerModule } from 'ngx-spinner';


@NgModule({
  declarations: [ProductDetailsComponent,CheckAvailabilityComponent,UserLoginComponent],
  imports: [
    CommonModule,
    ProductDetailsRoutingModule,
    TranslateModule,
    MatIconModule,
    MatDialogModule,
    MatFormFieldModule,
    FormsModule,
    ReactiveFormsModule,
    MatInputModule,
    VssuiteEcomModule,
    NgxImageZoomModule,
    NgxMaterialRatingModule,
    NgxSpinnerModule
  ]
})
export class ProductDetailsModule { }

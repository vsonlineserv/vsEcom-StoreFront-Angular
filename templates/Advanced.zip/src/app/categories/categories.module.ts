import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CategoriesRoutingModule } from './categories-routing.module';
import { CategoriesComponent } from './categories.component';
import { TranslateModule } from '@ngx-translate/core';
import { VssuiteEcomModule } from '@vssuite/vs-angular-ecom-components';

@NgModule({
  declarations: [CategoriesComponent],
  imports: [
    CommonModule,
    CategoriesRoutingModule,
    TranslateModule,
    VssuiteEcomModule,
  ]
})
export class CategoriesModule { }

import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { LandingService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../global';
import { GlobalService } from '../service/global.service';
import { TranslateService } from '@ngx-translate/core';
import { isPlatformBrowser } from '@angular/common';
import { Router } from '@angular/router';

@Component({
  selector: 'app-categories',
  templateUrl: './categories.component.html',
  styleUrls: ['./categories.component.css']
})
export class CategoriesComponent implements OnInit {

  mainMenu: any = [];
  categoryItems: any = [];
  categoryItemList: any = [];

  constructor(public global: Global, public globalService: GlobalService, private landingService: LandingService, private translateService: TranslateService,
    private router: Router, @Inject(PLATFORM_ID) private platformId: object) {
    translateService.use('en-us');
  }

  ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.global.configData = JSON.parse(localStorage.getItem('configData'))
    }
    this.getMenu();
  }

  getMenu() {
    this.landingService.GetMainMenu().subscribe((response: any) => {
      this.mainMenu = response;
      for (var i = 0; i < this.mainMenu.length; i++) {
          for (var j = 0; j < this.mainMenu[i].subMenu.length; j++) {
              this.categoryItemList.push(this.mainMenu[i].subMenu[j]);
          }
      }
      if(this.categoryItemList.length > 0){
        for(var k = 0; k < this.categoryItemList.length; k++){
          let eachCategory : any = {};
          eachCategory.pictureName = this.categoryItemList[k].categoryImage;
          eachCategory.name = this.categoryItemList[k].subCategoryName;
          eachCategory.productId = this.categoryItemList[k].subCategoryId;
          this.categoryItems.push(eachCategory)
        }
      }
    })
  }

  navigateProductsPage(event: any) {
    this.router.navigate(['category/' + event.ProductId]);
  }

}

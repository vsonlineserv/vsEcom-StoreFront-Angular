import { isPlatformBrowser } from '@angular/common';
import { Inject, Injectable, PLATFORM_ID } from '@angular/core';
import { UserToken } from './shared/models/user';

@Injectable()

export class Global {
    
     // For Showing Empty cart 
     vsShowEmptyCart: boolean = false;
     
    // Get Application Data Relates Globals
    currency: any;
    taxType: any;
    homeFolder: any;
    homeCategoryFolder: any;
    ApplicationHosting: any;

    //LoggedInUser Related Globals
    loggedInUserToken = new UserToken();
    flagLoggedIn: any;
    userName: any = '';
    curUserDisplayName: any;


    //Cart Related Globals
    cartlist: any;
    cartTotal = 0;
    cartCount: number = 0;
    cartFailureMessage = '';
    quantityFailureMessage = ''
    cartMessage = '';
    vshtmlfootersmallsocialLinkFlagShow: boolean = false;
    vshtmlfooterShowcontactInfo: boolean = false;
    totalShipping = 0;
    totalSaved: number = 0;
    compareListCount: number = 0;
    wishListCount: number = 0;
    comparisonlist: any = [];
    comparisonlistProductId: any = [];
    
    // Config Json Globals
    configData: any;
    configPages: any = [];
    metaTags: any;
    storeLogo: any;
    contactInfo: any;
    socialMediaLinks: any;
    //Other Globals
    recentlyViewedList: any = [];
    
    //Not Found Page
    showNotfoundPage: boolean = false;
    isDynamicPagesNotfound: boolean = false;

     // Checks if complete apiUrl is available
     isApiUrlAvailable: boolean = false;

     //Store Reference Id
     storeReferenceId: any;

    //Image base 
    imageUrl: string = 'https://storage.vsecommerce.com/stores/';
 

    constructor(@Inject(PLATFORM_ID) private platformId: object) {
        if (isPlatformBrowser(this.platformId)) {
            this.recentlyViewedList = JSON.parse(localStorage.getItem('recentlyViewedList')) || [];
            this.cartlist = JSON.parse(localStorage.getItem('cartlist')) || [];
            this.curUserDisplayName = localStorage.getItem('curUserDisplayName') || {};
            this.userName = localStorage.getItem('userName') || '';
            this.flagLoggedIn = localStorage.getItem('flagLoggedIn') || false;
            this.currency = localStorage.getItem('currency')
            this.taxType = localStorage.getItem('taxType')
            this.homeFolder = localStorage.getItem('homeFolder');
            this.comparisonlist = JSON.parse(localStorage.getItem('comparisonlist')) || [];
            this.configData = JSON.parse(localStorage.getItem('configData'));
            this.configPages = JSON.parse(localStorage.getItem('pages'));
            this.metaTags = JSON.parse(localStorage.getItem('metaTags'));
            this.storeLogo = localStorage.getItem('logo');
        }
    }

}
import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { CheckoutRoutingModule } from './checkout-routing.module';
import { CheckoutComponent } from './checkout.component';
import { FormsModule, ReactiveFormsModule } from '@angular/forms';
import { TranslateModule } from '@ngx-translate/core';
import { VssuiteEcomModule } from '@vssuite/vs-angular-ecom-components';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
  declarations: [CheckoutComponent],
  imports: [
    CommonModule,
    CheckoutRoutingModule,
    ReactiveFormsModule,
    FormsModule,
    TranslateModule,
    VssuiteEcomModule,
    NgxSpinnerModule
  ]
})
export class CheckoutModule { }

import { isPlatformBrowser } from '@angular/common';
import { Component, Inject, NgZone, OnInit, PLATFORM_ID } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Global } from '../global';
import { AuthService, WishlistService } from '@vsecom/vs-ecom-storefront-services';
import { CartService } from '@vsecom/vs-ecom-storefront-services';
import { CheckoutService } from '@vsecom/vs-ecom-storefront-services';
import { GlobalService } from '../service/global.service';
import { UserActionService } from '@vsecom/vs-ecom-storefront-services';
import { NgxSpinnerService } from 'ngx-spinner';
import { countries } from '../service/models/country-data-store';

declare var Razorpay: any;

@Component({
  selector: 'app-checkout',
  templateUrl: './checkout.component.html',
  styleUrls: ['./checkout.component.css']
})
export class CheckoutComponent implements OnInit {
  
  public countries:any = countries;
  loginErrorMessage: any = '';
  registerErrorMessage: any = '';
  checkoutAddress: any;
  loginForm: FormGroup;
  user: any = {};
  curUser: any = {};
  registerForm: FormGroup;
  buyerAddress: any;
  cartList: any = [];
  showLoginDiv: boolean = true;
  totalShipping: any = 0;
  cartTotal: any = 0;
  currency: any = '';
  netPayable: any;
  orderDiscount: any = 0;
  flagLoggedIn: any;
  submitted: boolean = false;
  couponCode: any = '';
  invalidCredential: boolean = false;
  tab: any = 'loginTab';
  enabledProvider: any;
  paymentOptionShow: any;
  paypalOrderId: any = '';
  paymentOption: any = 1;
  razorPaymentId: any = '';
  razorOrderId: any = '';
  razorSignature: any = '';
  amount: any = '';
  razorKey: any = '';
  razorGeneratedOrderId: any = '';
  defaultValues: any = '';
  data: any = '';
  taxType: any = '';
  deliveryDetails: any = '';
  deliveryOption: any;
  addressForm: FormGroup;
  paypalRendered : boolean = false;
  registerData: any = {};
  navigatehomepage:boolean=true;

  constructor(public global: Global, private authService: AuthService, public globalService: GlobalService, private userActionService: UserActionService,
    private router: Router, private cartService: CartService, private translateService: TranslateService, private checkoutService: CheckoutService,
    @Inject(PLATFORM_ID) private platformId: object, private wishlistService: WishlistService, private spinner: NgxSpinnerService, private zone: NgZone) {
    this.loginForm = new FormGroup({
      UserName: new FormControl('', [Validators.required]),
      Password: new FormControl('', [Validators.required]),
    });
    this.registerForm = new FormGroup({
      FirstName: new FormControl('', [Validators.required]),
      Email: new FormControl(null),
      Password: new FormControl('', [Validators.required]),
      ConfirmPassword: new FormControl('', [Validators.required]),
      PhoneNumber1: new FormControl('', [Validators.required])
    });
    this.addressForm = new FormGroup({
      Address1: new FormControl('', [Validators.required]),
      Address2: new FormControl(''),
      City: new FormControl('', [Validators.required]),
      PostalCode: new FormControl('', [Validators.required]),
      State: new FormControl('', [Validators.required]),
      PhoneNumber: new FormControl('', [Validators.required]),
      UserName: new FormControl(''),
      AddressId: new FormControl(''),
    });
    translateService.use('en-us');
  }

  async ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.global.currency = localStorage.getItem('currency');
      this.global.cartlist = JSON.parse(localStorage.getItem('cartlist'));
      this.global.taxType = localStorage.getItem('taxType');
      this.global.userName = localStorage.getItem('userName');
    }
    if (!this.global.cartlist || this.global.cartlist == 0) {
      this.global.vsShowEmptyCart = true;
    }
    else {
      this.global.vsShowEmptyCart = false;
    }
    this.initial();
    this.InitializeCart();
    this.loadRazorScript();
  }

  initial() {
    this.cartList = [];
    this.cartList = this.global.cartlist;
    this.globalService.CalculateCartTotal();
    if (this.global.userName && this.global.userName.length > 0) {
      this.GetBuyerAddress();
    }
  }

  InitializeCart() {
    this.cartService.getShippingType().subscribe((response: any) => {
      this.data = response;
      if (this.data != '') {
        this.cartService.getShippingDetails(this.data).subscribe((response: any) => {
          if (response.rate != '') {
            this.totalShipping = Number(response.rate);
            this.deliveryDetails = response;
          }
        });
      }

    });
    this.globalService.CalculateCartTotal();
  }

  GetBuyerAddress() {
    this.cartService.GetBuyerAddress(this.global.userName).subscribe((response: any) => {
      if (response != null) {
        this.addressForm.patchValue({
          Address1: response.address1,
          Address2: response.address2,
          City: response.city,
          PostalCode: response.postalCode,
          State: response.state,
          Country: response.country,
          PhoneNumber: response.phoneNumber,
          UserName: this.global.userName,
          AddressId: response.addressId
        })
        this.buyerAddress = response;
        this.tab = 'loginTab';
      }
    });
    this.cartService.EnabledProviderDetaile().subscribe((response: any) => {
      if (response && response.length > 0) {
        this.enabledProvider = response;
        this.paymentOptionShow = this.enabledProvider[0].providerName;
        if (this.paymentOptionShow == 'PayPal') {
          this.checkoutService.GetProviderDetails().subscribe((response: any) => {
            if (response.payPalSecretId) {
              let payPalUrlSrc = "https://www.paypal.com/sdk/js?client-id=" + response.payPalSecretKey;
              this.loadExternalScript(payPalUrlSrc).then(() => {
                setTimeout(() => {
                  this.paypal(this);
                }, 100);
              });

            }
          });
        }
        for (let i = 0; i < response.length; i++) {
          if (response[i].providerId == 4) {
            this.checkoutService.GetProviderDetails().subscribe((response: any) => {
              if (response.payPalSecretId) {
                let payPalUrlSrc = "https://www.paypal.com/sdk/js?client-id=" + response.payPalSecretKey;
                this.loadExternalScript(payPalUrlSrc).then(() => {
                  setTimeout(() => {
                    this.paypal(this);
                  }, 100);
                });
              }
            });
          }
        }
      }
    });
  }

  addBuyerAddress(event:any) {
    this.submitted = true;
    if (event) {
      event.addressData.UserName = this.global.userName
      this.cartService.AddBuyerAddress(event.addressData).subscribe((response: any) => {
        if (response != null) {
          this.addressForm.patchValue({
            Address1: response.address1,
            Address2: response.address2,
            City: response.city,
            PostalCode: response.postalCode,
            State: response.state,
            Country: response.country,
            PhoneNumber: response.phoneNumber,
            UserName: this.global.userName,
            AddressId: response.addressId
          })
          this.buyerAddress = response;
        }
        this.tab = 'paymentTab';
      }, error => {
      });
      this.cartService.EnabledProviderDetaile().subscribe((response: any) => {
        this.enabledProvider = response;
        if (this.enabledProvider) {
          this.paymentOptionShow = this.enabledProvider[0].providerName;
          if (this.paymentOptionShow == 'PayPal') {
            this.checkoutService.GetProviderDetails().subscribe((response: any) => {
              if (response.payPalSecretId) {
                let payPalUrlSrc = "https://www.paypal.com/sdk/js?client-id=" + response.payPalSecretKey;
                this.loadExternalScript(payPalUrlSrc).then(() => {
                  setTimeout(() => {
                    this.paypal(this);
                  }, 100);
                });

              }
            });
          }
          for (let i = 0; i < response.length; i++) {
            if (response[i].providerId == 4) {
              this.checkoutService.GetProviderDetails().subscribe((response: any) => {
                if (response.payPalSecretId) {
                  let payPalUrlSrc = "https://www.paypal.com/sdk/js?client-id=" + response.payPalSecretKey;
                  this.loadExternalScript(payPalUrlSrc).then(() => {
                    setTimeout(() => {
                      this.paypal(this);
                    }, 100);
                  });
                }
              });
            }
          }
        }
      });
    }

  }

  navigateHomePage(){
    this.router.navigate(['home'])

  }
  gotohome(){
    if(this.navigatehomepage){
      setTimeout(function()
      { window.location.assign('/home')
     }, 3000)
    }
  } 

  register(event) {
    this.submitted = true;
    this.registerData = event.registerData;
    this.authService.RegisterUser(event.registerData).subscribe((response: any) => {
      this.submitted = false;
      this.registeredUserLogin();
    }, error => {
      this.tab = 'loginTab';
      this.registerErrorMessage = error.error;
    });
  }

  registeredUserLogin(){
    if(this.registerData.Email && this.registerData.PhoneNumber1){
      this.registerData.UserName = this.registerData.Email
    }
    if(this.registerData.PhoneNumber1 && (this.registerData.Email == undefined || this.registerData.Email == '' || this.registerData.Email == null)){
      this.registerData.UserName = this.registerData.PhoneNumber1
    }
    this.authService.Login(this.registerData).subscribe((response) => {
      let tokenObj: any = {};
      Object.assign(tokenObj, response)
      this.globalService.SetLoggedInUserToken(tokenObj);
      this.global.flagLoggedIn = true;
      this.global.userName = this.registerData.UserName;
      this.global.curUserDisplayName = '';
      this.tab = 'loginTab';
      this.loadUserDefaults();
      this.getUserWishlistCount();
    }, err => {
      this.tab = 'loginTab';
      this.loginErrorMessage = err.error;
      this.global.flagLoggedIn = false;
      this.globalService.ClearCookieStore();
    });
  }
  login(event:any) {
    this.authService.Login(event.loginData).subscribe((response) => {
      let tokenObj: any = {};
      Object.assign(tokenObj, response)
      this.globalService.SetLoggedInUserToken(tokenObj);
      this.global.flagLoggedIn = true;
      this.global.userName = event.loginData.UserName;
      this.global.curUserDisplayName = '';
      this.tab = 'loginTab';
      this.loadUserDefaults();
    }, err => {
      this.tab = 'loginTab';
      this.loginErrorMessage = err.error;
      this.global.flagLoggedIn = false;
      this.globalService.ClearCookieStore();
    });
  }

  loadUserDefaults() {
    if (this.global.userName && this.global.userName.length > 0) {
      this.userActionService.GetUserDetails(this.global.userName)
        .subscribe((response: any) => {
          this.GetBuyerAddress();
          this.curUser.Email = response.email;
          this.curUser.PhoneNumber1 = response.phoneNumber1;
          this.curUser.FirstName = response.firstName;
          this.curUser.LastName = response.lastName;
          this.global.curUserDisplayName = response.firstName;
          if (response.email || response.phoneNumber1) {
            if (isPlatformBrowser(this.platformId)) {
              localStorage.setItem('flagLoggedIn', this.global.flagLoggedIn);
              localStorage.setItem('userName', this.global.userName);
              localStorage.setItem('curUserDisplayName', this.global.curUserDisplayName);
            }
          }
        });
      if (this.global.cartlist && this.global.cartlist.length > 0) {
        this.cartService.AddShoppingCartItemList(this.global.cartlist, this.global.userName)
          .subscribe((response: any) => {
            this.getShoppingCartItems();
          });
      }
      else {
        this.getShoppingCartItems();
      }
    }
  }

  getShoppingCartItems() {
    this.cartService.GetShoppingCartItems(this.global.userName).subscribe((response: any) => {
      if (response.length > 0) {
        this.global.cartlist = [];
        for (var i = 0; i < response.length; i++) {
          let addtoCartProduct = this.createCartListProductObjectFromList(response[i]);

          this.global.cartlist.push(addtoCartProduct);
        }
        if (this.global.cartlist && this.global.cartlist.length > 0) {
          if (isPlatformBrowser(this.platformId)) {
            localStorage.setItem('cartlist', JSON.stringify(this.global.cartlist));
          }
        }
        else {
          if (isPlatformBrowser(this.platformId)) {
            this.global.cartlist = JSON.parse(localStorage.getItem('cartlist'));
          }
        }
      }
      this.globalService.CalculateCartTotal();
    });
  }

  createCartListProductObjectFromList(product: any) {
    if (product.productId > 0) {
      let cart: any = {};
      cart.ProductId = product.productId;
      cart.Name = product.name;
      cart.PictureName = product.pictureName;
      cart.SpecialPrice = product.specialPrice;
      cart.Price = product.price;
      cart.Branch = product.branch;
      cart.BranchId = product.branchId;
      cart.StoresCount = product.storesCount;
      cart.FlagWishlist = product.flagWishlist;
      cart.Quantity = product.quantity;
      cart.SelectedSize = product.selectedSize;
      cart.AdditionalShippingCharge = product.additionalShippingCharge;
      cart.TotalAdditionalShippingCharge = product.additionalShippingCharge * cart.Quantity;
      cart.SubTotal = (cart.SpecialPrice * cart.Quantity);
      cart.SubTotalWithShipping = (cart.SpecialPrice * cart.Quantity) + cart.TotalAdditionalShippingCharge;
      return cart;
    }
  }

  resetForm() {
    this.loginForm.reset();
  }

  applyCoupon(event) {
    this.couponCode = event.couponCode;
    this.cartService.GetCartDiscount(this.global.userName, event.couponCode).subscribe((response) => {
      this.orderDiscount = response;
    });
  }

  showPaymentMehtod(event) {
    // $(".payOptions").removeClass("active");
    let payOptions = document.getElementsByClassName("payOptions");
    for (let i = 0; i < payOptions.length; i++) {
      payOptions[i].classList.remove("active");
    }
    event.eventdata.classList.add("active");
    this.paymentOption = event.id;
    if (event.id == 1 || event.id == 2 || event.id == 3) {
      this.paypalRendered = true;
      this.paymentOptionShow = 'confirmOrder';
    } else if (event.id == 4) {
      this.paymentOptionShow = 'PayPal';
      setTimeout(() => {
        this.paypal(this);
      }, 100);
      // setTimeout(this.paypal, 100);
    } else if (event.id == 5) {
      this.paypalRendered = true;
      this.paymentOptionShow = 'Razor';
    }
  }


  paypal(modal) {
    if(modal == undefined) {
      return
    }
    if(modal.paypalRendered) {
      return
    }
    //remove the amount, used for testing
    let amount = ((((this.global.cartTotal * this.global.taxType) / 100)) + (this.global.cartTotal - this.orderDiscount) + (this.totalShipping));
    <any>window['paypal'].Buttons({
      createOrder: (data, actions) => {
        return actions.order.create({
          purchase_units: [{
            amount: {
              value: amount,
              currency_code: "USD"
            },
          },],
        });
      },
      onApprove: (data, actions) => {
        console.log("data -> " + data);
        return actions.order.capture().then(details => {
          console.log(details);
          this.paypalOrderId = data.orderID;
          modal.confirmOrder();
        });
      },
    }).render('#paypal-button-container').then(function () {
      // this.paypalRendered = true;
      modal.paypalRendered = true;
    });

  }

  private loadExternalScript(scriptUrl: string) {
    return new Promise((resolve, reject) => {
      let isFound = false;
      let scripts = document.getElementsByTagName('script');
      for (let i = 0; i < scripts.length; ++i) {
        if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src').includes('www.paypal.com')) {
          isFound = true;
        }
      }
      if (!isFound) {
        const scriptElement = document.createElement('script');
        scriptElement.src = scriptUrl;
        scriptElement.onload = resolve;
        document.body.appendChild(scriptElement);
      }
    })
  }


  showAccountDiv() {
    if (this.showLoginDiv) {
      this.showLoginDiv = false;
    } else {
      this.showLoginDiv = true;
    }
  }

  createRazorOrderId(event) {
    this.spinner.show();
    // let amount = ((((event.cartTotal * this.global.taxType) / 100)) + (event.cartTotal - this.orderDiscount) + (this.totalShipping));
    this.cartService.GenerateRazorOrderId(event.cartTotal).subscribe((response: any) => {
      this.spinner.hide();
      if (response.amount == 0) {
        alert("Error while Placing order");
        return;
      }
      this.razorGeneratedOrderId = response.razorOrderId;
      this.razorKey = response.razorKeyId;
      this.amount = response.amount;
      this.Razor();
      document.getElementById("rzp-button1").click();
    }, error => {
      this.spinner.hide();
    });
  }

  changeAddress() {
    this.tab = 'loginTab';
  }

  Razor() {
    let razorModal = this;
    let options = {
      "key": this.razorKey,
      "amount": this.amount,
      "currency": "INR",
      "name": "Store Name", //can change?
      "description": "Purchase", // can change?
      "order_id": this.razorGeneratedOrderId.toString(),
      "handler": function (response) {
        razorModal.razorPaymentId = response.razorpay_payment_id;
        razorModal.razorOrderId = response.razorpay_order_id;
        razorModal.razorSignature = response.razorpay_signature;
        razorModal.confirmOrder();
      },
      "prefill": {
        // later add the user details here
        // "name": "Gaurav Kumar",
        // "email": "mailto:gaurav.kumar@example.com",
        // "contact": "9999999999"
      },
      "notes": {
        "address": "Razorpay Corporate Office"
      },
      "theme": {
        "color": "#3399cc"
      }
    };
    let rzp1 = new Razorpay(options);
    rzp1.on('payment.failed', function (response) {
      alert(response.error.description);

    });
    document.getElementById('rzp-button1').onclick = function (e) {
      rzp1.open();
      e.preventDefault();
    }
  }

  confirmOrder() {
    // ===============For initial version we hardcoded delivery option================
    let deliveryOption = 1;
    this.spinner.show();
    this.cartService.GenerateOrder(this.global.cartlist, this.global.userName, this.paymentOption, deliveryOption,
      this.couponCode, this.paypalOrderId, this.razorPaymentId, this.razorOrderId, this.razorSignature,
      this.razorGeneratedOrderId).subscribe((data: any) => {
        this.spinner.hide();
        // let responseString = data.slice(1, -1);
        let response = Number(data);
        if (this.paymentOption == 4 || this.paymentOption == 5) {
          if (response == 0) {
            alert("Payment Verification Failed");
            this.navigatehomepage=false;
            return;
          }
          this.cartList = [];
          this.cartTotal = 0;
          this.global.cartTotal = 0;
          this.global.cartlist = [];
          if (response > 0 || response > 25) {
            if (isPlatformBrowser(this.platformId)) {
              this.navigatehomepage=false;
              localStorage.removeItem('cartlist');
            }
          }
          this.zone.run(() => {
            this.router.navigate(['confirm-order'], { queryParams: { orderId: response } });
          });
        } else {
          this.cartList = [];
          this.cartTotal = 0;
          this.global.cartTotal = 0;
          this.global.cartlist = [];
          if (response > 0 || response > 25) {
            if (isPlatformBrowser(this.platformId)) {
              this.navigatehomepage=false;
              localStorage.removeItem('cartlist');
            }
            this.router.navigate(['/confirm-order'], { queryParams: { orderId: response } });
          } else if (response > 25) {
            //if payment gateway
            if (isPlatformBrowser(this.platformId)) {
              document.write(response.toString());
            }
            // $("#payuForm").submit();
          } else {
            this.router.navigate(['confirm-order'], { queryParams: { orderid: response } });
          }
        }
      }, error => {
        this.spinner.hide();
      });
  }

  loadRazorScript() {
    let isFound = false;
    let scripts = document.getElementsByTagName('script');
    for (let i = 0; i < scripts.length; ++i) {
      if (scripts[i].getAttribute('src') != null && scripts[i].getAttribute('src').includes('checkout.js')) {
        isFound = true;
      }
    }
    if (!isFound) {
      let node = document.createElement('script');
      node.src = 'https://checkout.razorpay.com/v1/checkout.js';
      node.type = 'text/javascript';
      node.async = false;
      node.charset = 'utf-8';
      document.getElementsByTagName('head')[0].appendChild(node);
    }
  }

  getUserWishlistCount(){
    if (this.global.userName && this.global.userName.length > 0) {
      this.wishlistService.GetUserWishlistCount(this.global.userName).subscribe((response: any) => {
        this.global.wishListCount = response;
      });
    }
  }

}


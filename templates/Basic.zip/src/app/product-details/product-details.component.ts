import { isPlatformBrowser } from '@angular/common';
import { Component, Inject, OnDestroy, OnInit, Pipe, PLATFORM_ID } from '@angular/core';
import { Meta, Title } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { CheckAvailabilityComponent } from '../components/check-availability/check-availability.component';
import { Global } from '../global';
import { CartService } from '@vsecom/vs-ecom-storefront-services';
import { GlobalService } from '../service/global.service';
import { LandingService } from '@vsecom/vs-ecom-storefront-services';
import { ProductService } from '@vsecom/vs-ecom-storefront-services';
import { MatDialog, MatDialogConfig } from '@angular/material/dialog';
import { UserLoginComponent } from '../components/user-login/user-login.component';
import { HttpClient } from '@angular/common/http';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-product-details',
  templateUrl: './product-details.component.html',
  styleUrls: ['./product-details.component.css']
})

export class ProductDetailsComponent implements OnInit, OnDestroy {

  product: any = [];
  productImages: any = [];
  selectedVariant: any;
  specification: any;
  productSpecification: any = [];
  productKeyFeatures: any = [];
  defaultValues: any;
  contactData: any;
  imgSrc: any;
  flagLocationBased: boolean = true;
  productRating: any;
  ProductId: any;
  ProductName: any;
  productExist: boolean = false;
  isLoadingRoute: boolean = false;
  imageBase: any;
  checkAvailabilityProductId: any = '';
  checkAvailabilityBranchId: any = '';
  productSpecialPrice: any;
  productVariant: any = [];
  selectSize: any;
  selectOption: any;
  selectColor: any;
  productPrice: any;
  productVariantList: any = [];
  variantsId: any;
  selectList: any =[];

  constructor(public global: Global, private router: Router, private landingService: LandingService, public translateService: TranslateService,
    @Inject(PLATFORM_ID) private platformId: object, private meta: Meta, private titleService: Title, public globalService: GlobalService, private productService: ProductService,
    private cartService: CartService, private route: ActivatedRoute, public matDialog: MatDialog, private httpClient: HttpClient, private spinner: NgxSpinnerService) {
      route.params.subscribe(val => {
        this.ProductId = route.snapshot.params['id'];
        this.getAppData();
      });
    translateService.use('en-us');
  }

  ngOnInit() {
    this.global.cartMessage = '';
  }

  getAppData() {
      this.GetProductDetailsWithVariant();
      this.loadProductKeyFeatures();
      this.loadProductSpecification();
  }

  GetProductDetailsWithVariant() {
    this.spinner.show();
    this.productService.GetProductVariant(this.ProductId,this.flagLocationBased).subscribe((response: any) => {
      this.spinner.hide();
      this.productVariant = [];
      this.productVariantList = [];
      Object.assign(this.productVariant, response);
      this.updateMetaInfo(this.productVariant);
      if(this.productVariant.variantOptions && this.productVariant.variantOptions.length > 0){
        for(let i = 0; i < this.productVariant.variantOptions.length; i++){
        let VariantHeading =  this.productVariant.variantOptions[i];
            if(i == 0){
              let Variants = this.productVariant.option1;
              let data = {
                heading : VariantHeading,
                variants : Variants
              }
              this.productVariantList.push(data);
            }
            if(i == 1){
              let Variants = this.productVariant.option2;
              let data = {
                heading : VariantHeading,
                variants : Variants
              }
              this.productVariantList.push(data);
            }
            if(i == 2){
              let Variants = this.productVariant.option3;
              let data = {
                heading : VariantHeading,
                variants : Variants
              }
              this.productVariantList.push(data);
            }
        }
        this.selectColor = this.productVariant.productVariants[0].option1;
        this.selectSize = this.productVariant.productVariants[0].option2;
        this.selectOption = this.productVariant.productVariants[0].option3;
        let productVariantId = this.productVariant.productVariants[0].productVariantId;
        this.changeStorePricing(productVariantId);
      }
    }, error => {
      this.spinner.hide();
    })
  }

  changeStorePricing(variantId){
    let productVariantId = variantId;
    for(let i = 0; i < this.productVariant.storePricingModel.length; i++){
      let variantId = this.productVariant.storePricingModel[i].productVariantId;
      if(variantId == productVariantId){
        this.productSpecialPrice = this.productVariant.storePricingModel[i].specialPrice;
        this.productPrice = this.productVariant.storePricingModel[i].price;
        this.variantsId = variantId
        return
  
      }
    }
  }

  updateMetaInfo(data: any) {
    if (data) {
      this.titleService.setTitle(data.name);
      this.meta.updateTag({ property: 'og:title', content: data.name });
      this.meta.updateTag({ property: 'og:url', content: "product-details" });
      this.meta.updateTag({ property: 'og:description', content: data.fullDescription });
      this.meta.updateTag({ property: 'twitter:title', content: data.name });
      this.meta.updateTag({ property: 'twitter:url', content: "product-details" });
      this.meta.updateTag({ property: 'twitter:description', content: data.fullDescription });
      this.meta.updateTag({ property: 'keywords', content: data.name });
      this.meta.updateTag({ name: 'description', content: data.fullDescription });
      for (let i = 0; i < data.productImages.length; i++) {
        this.meta.updateTag({ property: 'og:image', content: data.productImages[i] });
        this.meta.updateTag({ property: 'twitter:image', content: data.productImages[i] });
      }

    }
  }

  loadProductKeyFeatures() {
    this.productService.GetProductKeyFeatures(this.ProductId).subscribe((data) => {
      this.productKeyFeatures = data;
    });
  }

 

  updateVariant(event){
    for(var i = 0; i < this.productVariant.productVariants.length; i++){
      if(event.value == this.productVariant.productVariants[i].option1){
        if(this.productVariant.productVariants[i].option2 == this.selectSize && this.productVariant.productVariants[i].option3 == this.selectOption){
          this.selectColor = event.value;
          let productVariantId = this.productVariant.productVariants[i].productVariantId;
          if(event.e.target){
            if(event.e.target.className == "vs-color-input"){
              var selectClick = document.getElementsByClassName("selectColor");
            }
            else{
              var selectClick = document.getElementsByClassName("selectSize");
            }
            for(var j=0;j<this.productVariantList.length;j++){
              for(var l=0;l<this.productVariantList[j].variants.length;l++){
                if(event.value == this.productVariantList[j].variants[l]){
                  this.selectList = this.productVariantList[j].variants
                  for(var m=0; m<this.selectList.length; m++){
                    for(var k=0;k<selectClick.length;k++) {
                      const input = selectClick[k] as HTMLElement;
                      if(this.selectList[m] == input.innerText || input.innerText == ""){
                        selectClick[k].classList.remove("selectClick");
                      }
                    }
                  }
                }
              }
            }
          }
          this.changeStorePricing(productVariantId);
          event.e.currentTarget.classList.add("selectClick");
        }
      }
      else if(event.value == this.productVariant.productVariants[i].option2){
        if(this.productVariant.productVariants[i].option1 == this.selectColor && this.productVariant.productVariants[i].option3 == this.selectOption){
          this.selectSize = event.value;
          let productVariantId = this.productVariant.productVariants[i].productVariantId;
          if(event.e.target){
            if(event.e.target.className == "vs-color-input"){
              var selectClick = document.getElementsByClassName("selectColor");
            }
            else{
              var selectClick = document.getElementsByClassName("selectSize");
            }
            for(var j=0;j<this.productVariantList.length;j++){
              for(var l=0;l<this.productVariantList[j].variants.length;l++){
                if(event.value == this.productVariantList[j].variants[l]){
                  this.selectList = this.productVariantList[j].variants
                  for(var m=0; m<this.selectList.length; m++){
                    for(var k=0;k<selectClick.length;k++) {
                      const input = selectClick[k] as HTMLElement;
                      if(this.selectList[m] == input.innerText || input.innerText == ""){
                        selectClick[k].classList.remove("selectClick");
                      }
                    }
                  }
                }
              }
            }
          }
          this.changeStorePricing(productVariantId);
          event.e.currentTarget.classList.add("selectClick");
        }
      }
      else if(event.value == this.productVariant.productVariants[i].option3){
        if(this.productVariant.productVariants[i].option1 == this.selectColor && this.productVariant.productVariants[i].option2 == this.selectSize){
          this.selectOption = event.value;
          let productVariantId = this.productVariant.productVariants[i].productVariantId;
          if(event.e.target){
            if(event.e.target.className == "vs-color-input"){
              var selectClick = document.getElementsByClassName("selectColor");
            }
            else{
              var selectClick = document.getElementsByClassName("selectSize");
            }
            for(var j=0;j<this.productVariantList.length;j++){
              for(var l=0;l<this.productVariantList[j].variants.length;l++){
                if(event.value == this.productVariantList[j].variants[l]){
                  this.selectList = this.productVariantList[j].variants
                  for(var m=0; m<this.selectList.length; m++){
                    for(var k=0;k<selectClick.length;k++) {
                      const input = selectClick[k] as HTMLElement;
                      if(this.selectList[m] == input.innerText || input.innerText == ""){
                        selectClick[k].classList.remove("selectClick");
                      }
                    }
                  }
                }
              }
            }
          }
          this.changeStorePricing(productVariantId);
          event.e.currentTarget.classList.add("selectClick");
        }
      }
    }
  }

  loadProductSpecification() {
    this.productService.GetProductSpecification(this.ProductId).subscribe((data) => {
      this.productSpecification = data;
    })
  }

  updateSelectedVariant(productSize) {

  }

  addProductToCart(event: any) {
    this.productExist = this.FlagProductAlreadyExistinCart(event.product);
    if (!this.productExist) {
      var addtoCartProduct = this.CreateCartListProductObject(event.product, event.branchId, event.branchName, event.price, event.specialPrice, event.additionalShippingCharge, event.deliveryTime, event.selectedSize);
      if (addtoCartProduct != null) {
        if (this.global.flagLoggedIn) {
          this.cartService.AddShoppingCartItem(addtoCartProduct, this.global.userName).subscribe((response: any) => {
            if(response != ''){
              this.global.totalSaved = 0;
              for(var i = 0; i < response.length; i++){
                this.global.totalSaved = this.global.totalSaved + response[i].totalSaved;
              }
            }
           });
        }
        if (!this.global.cartlist || !this.global.cartlist.length || this.global.cartlist == null) {
          this.global.cartlist = [];
        }
        this.global.cartlist.push(addtoCartProduct);
        if (this.global.cartlist && this.global.cartlist.length > 0) {
          if (isPlatformBrowser(this.platformId)) {
            localStorage.setItem('cartlist', JSON.stringify(this.global.cartlist));
          }
        }
        this.global.cartMessage = "Success";
        this.hideSuccessDiv();
      } else {
        this.global.cartFailureMessage = "Failure";
        this.hideSuccessDiv();
      }
    }
    this.globalService.CalculateCartTotal();
  }

  FlagProductAlreadyExistinCart(product) {
    if (this.global.cartlist) {
      for (var i = 0; i < this.global.cartlist.length; i++) {
        if (this.global.cartlist[i].ProductId == product.productId) {
          this.global.cartlist[i].Quantity = this.global.cartlist[i].Quantity + 1;
          this.global.cartlist[i].TotalAdditionalShippingCharge = this.global.cartlist[i].AdditionalShippingCharge * this.global.cartlist[i].Quantity;
          this.global.cartlist[i].SubTotal = (this.global.cartlist[i].SpecialPrice * this.global.cartlist[i].Quantity);
          this.global.cartlist[i].SubTotalWithShipping = ((this.global.cartlist[i].SpecialPrice * this.global.cartlist[i].Quantity) + this.global.cartlist[i].TotalAdditionalShippingCharge);
          if(this.global.userName != "" && this.global.userName != null){
            this.cartService.UpdateCartItemQuantity(this.global.cartlist[i], this.global.userName).subscribe((response: any) => {
              if(response != ''){
                this.global.totalSaved = 0;
                for(var i = 0; i < response.length; i++){
                  this.global.totalSaved = this.global.totalSaved + response[i].totalSaved;
                }
              }
            });
          }
          this.global.cartMessage = "Success";
          this.hideSuccessDiv();
          return this.productExist = true;
        }
      }
    }
    return this.productExist = false;
  }

  CreateCartListProductObject(product, branchId, branchName, price, specialPrice, additionalShippingCharge, deliveryTime, selectedSize) {
    if (product.storePricingModel && product.storePricingModel.length > 0) {
      let cart: any = {};
      cart.ProductId = product.productId;
      cart.Name = product.name;
      cart.PictureName = product.productImages[0];
      cart.SpecialPrice = specialPrice;
      cart.Price = price;
      cart.Branch = branchName;
      cart.BranchId = branchId;
      cart.StoresCount = product.storesCount;
      cart.FlagWishlist = product.flagWishlist;
      cart.Quantity = 1;
      cart.AdditionalShippingCharge = additionalShippingCharge;
      cart.TotalAdditionalShippingCharge = additionalShippingCharge * cart.Quantity;
      cart.SubTotal = (cart.SpecialPrice * cart.Quantity);
      cart.SubTotalWithShipping = (cart.SpecialPrice * cart.Quantity) + cart.TotalAdditionalShippingCharge;
      cart.DeliveryTime = deliveryTime;
      cart.SelectedSize = selectedSize;
      return cart;
    } else {
      let cart: any = {};
      cart.ProductId = product.productId;
      cart.Name = product.name;
      cart.PictureName = product.productImages[0];
      cart.SpecialPrice = specialPrice;
      cart.Price = price;
      cart.Branch = branchName;
      cart.BranchId = branchId;
      cart.Quantity = 1;
      cart.AdditionalShippingCharge = additionalShippingCharge;
      cart.TotalAdditionalShippingCharge = additionalShippingCharge * cart.Quantity;
      cart.SubTotal = (cart.SpecialPrice * cart.Quantity);
      cart.SubTotalWithShipping = (cart.SpecialPrice * cart.Quantity) + cart.TotalAdditionalShippingCharge;
      cart.DeliveryTime = deliveryTime;
      cart.SelectedSize = selectedSize;
      return cart;
    }
  }

  hideSuccessDiv() {
    if (this.global.cartMessage) {
      setTimeout(() => {
          document.getElementById('cart-success-alert').classList.add('hidden');
          this.global.cartMessage = '';
      }, 1000);
    }
    else if (this.global.cartFailureMessage) {
      setTimeout(() => {
        document.getElementById('cart-failure-alert').classList.add('hidden');
        this.global.cartMessage = '';
      }, 1000);
    }
  }

  ngOnDestroy() {
    this.addTorecentlyViewedList(this.productVariant);
  }

  addTorecentlyViewedList(product) {
    if (product) {
      let alreadyExist = false;
      if (this.global.recentlyViewedList && this.global.recentlyViewedList.length > 0) {
        for (var i = 0; i < this.global.recentlyViewedList.length; i++) {
          if (product.productId == this.global.recentlyViewedList[i].productId) {
            alreadyExist = true;
          }
        }
      }
      if (!alreadyExist) {
        var recentViewedProduct = this.CreateRecentlyViewedList(product);
        if (this.global.recentlyViewedList && this.global.recentlyViewedList.length >= 20) {
          this.global.recentlyViewedList.splice(0, 2);
        }
        this.global.recentlyViewedList.push(recentViewedProduct);
        if (isPlatformBrowser(this.platformId)) {
          localStorage.setItem('recentlyViewedList', JSON.stringify(this.global.recentlyViewedList));
        }
      }
    }
  }

  CreateRecentlyViewedList(product) {
    if (product) {
      let recentProduct: any = {};
      recentProduct.productId = product.productId;
      recentProduct.name = product.name;
      if (product.productImages) {
        recentProduct.pictureName = product.productImages[0];
      }
      recentProduct.specialPrice = product.storePricingModel[0].specialPrice;
      recentProduct.price = product.storePricingModel[0].price;
      recentProduct.permaLink = product.permaLink;
      return recentProduct;
    }
  }

  navigateProductsPage(categoryId: any) {
    this.router.navigate(['category/' + categoryId]);
  }

  checkAvailityForm(event: any) {
    this.checkAvailabilityProductId = event.id;
    this.checkAvailabilityBranchId = event.branchId;
    if (this.global.userName && this.global.userName.length > 0) {
      const dialogConfig = new MatDialogConfig();
      dialogConfig.data = {
        productId: event.id,
        branchId: event.branchId
      };
      dialogConfig.width = "550px";
      let dialogRef = this.matDialog.open(CheckAvailabilityComponent, dialogConfig);
      dialogRef.afterClosed().subscribe((value: any) => {
      });
    }
    else{
      this.openLogin();
    }
  }

  openLogin() {
    const dialogConfig = new MatDialogConfig();
    dialogConfig.width = "500px";
    let dialogRef = this.matDialog.open(UserLoginComponent, dialogConfig);
    dialogRef.afterClosed().subscribe((value: any) => {
      if(value == true){
        const dialogConfig = new MatDialogConfig();
        dialogConfig.data = {
          productId: this.checkAvailabilityProductId,
          branchId: this.checkAvailabilityBranchId
        };
        dialogConfig.width = "550px";
        let dialogRef = this.matDialog.open(CheckAvailabilityComponent, dialogConfig);
        dialogRef.afterClosed().subscribe((value: any) => {
        });
      }
    });
  }

}
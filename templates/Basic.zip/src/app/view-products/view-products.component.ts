import { isPlatformBrowser } from '@angular/common';
import { Component, Inject, OnChanges, OnInit, PLATFORM_ID } from '@angular/core';
import { Title, Meta } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Global } from '../global';
import { GlobalService } from '../service/global.service';
import { LandingService } from '@vsecom/vs-ecom-storefront-services';
import { ProductService } from '@vsecom/vs-ecom-storefront-services';
import { NgxSpinnerService } from 'ngx-spinner';

@Component({
  selector: 'app-view-products',
  templateUrl: './view-products.component.html',
  styleUrls: ['./view-products.component.css']
})
export class ViewProductsComponent implements OnInit {

  productsCount: number = 0;
  productsList: any = [];
  categoryId: any;
  pageStart: any;
  pageSize: any;
  productFilterListSelected: any = [];
  priceRangeFrom = 0;
  priceRangeTo = 100000;
  selectedFilter = {
    SelectedBrandList: [],
    SelectedProductFilter1: [],
    SortBy: {
      id: ''
    }
  };
  dropdownSortData = [{ id: 1, label: "Stores Count" }, { id: 2, label: "Low Price" }, { id: 3, label: "High Price" }, { id: 4, label: "A to Z" }, { id: 5, label: "Z to A" }];
  metaProductsList: any = {};
  imageBase: any;
  showNoProducts: boolean = false;

  constructor(public translateService: TranslateService, public global: Global, private productService: ProductService, private route: ActivatedRoute,
    private landingService: LandingService, public globalService: GlobalService, private router: Router, private title: Title, private meta: Meta, 
    @Inject(PLATFORM_ID) private platformId: object, private spinner: NgxSpinnerService) {
      route.params.subscribe(val => {
        this.categoryId = route.snapshot.params['id'];
        this.getProducts();

      });
    translateService.use('en-us');
  }

  ngOnInit() {

  }

  getProducts() {
    this.spinner.show();
    this.productService.GetProducts(this.categoryId, null, this.priceRangeFrom, this.priceRangeTo, '', '', null).subscribe((response) => {
      this.spinner.hide();
      this.productsList = response;
      Object.assign(this.metaProductsList, this.productsList[0]);
      this.updateMetaInfo(this.metaProductsList);
      if (this.productsList) {
        this.productsCount = this.productsList.length;
      }
      this.displayNoProducts();
    }, error => {
      this.spinner.hide();
      this.displayNoProducts();
    });
  }

  updateMetaInfo(data: any) {
    if (data) {
      if(data.fullDescription == undefined || data.fullDescription == null || data.fullDescription == ""){
        data.fullDescription = 'Category Page';
      }
      if(data.parentCategoryName == undefined || data.parentCategoryName == null || data.parentCategoryName == ""){
        data.parentCategoryName = 'Category';
      }
      this.title.setTitle(data.parentCategoryName);
      this.meta.updateTag({ property: 'og:title', content: data.parentCategoryName });
      this.meta.updateTag({ property: 'og:description', content: data.fullDescription });
      this.meta.updateTag({ property: 'og:image', content: data.pictureName });
      this.meta.updateTag({ property: 'og:url', content: "product-details" });
      this.meta.updateTag({ property: 'twitter:title', content: data.parentCategoryName });
      this.meta.updateTag({ property: 'twitter:description', content: data.fullDescription });
      this.meta.updateTag({ property: 'twitter:image', content: data.pictureName });
      this.meta.updateTag({ property: 'keywords', content: data.parentCategoryName });
      this.meta.updateTag({ name: 'description', content: data.fullDescription });
;
    }
  }

  getSubCategory(id) {
    this.selectedFilter.SortBy.id = id;
    this.selectedFilter;
    this.spinner.show()
    this.productService.GetProducts(this.categoryId, this.selectedFilter, this.priceRangeFrom, this.priceRangeTo, '', '', null).subscribe((response) => {
      this.spinner.hide();
      this.productsList = response;
    }, error => {
      this.spinner.hide();
    });
  }

  displayNoProducts() {
    if (this.productsList && this.productsList.length == 0) {
      this.showNoProducts = true;
    }
  }

  navigateHomePage(){
    if (isPlatformBrowser(this.platformId)) {
      window.scrollTo(0,0);
      this.router.navigate(['home'])
    }
  }
  
}

import { DOCUMENT, isPlatformBrowser } from '@angular/common';
import { HttpClient } from '@angular/common/http';
import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { FormControl } from '@angular/forms';
import { ActivatedRoute, NavigationEnd, Router } from '@angular/router';
import { TranslateService } from '@ngx-translate/core';
import { Observable, startWith, debounceTime, distinctUntilChanged, switchMap, map, filter, mergeMap } from 'rxjs';
import { GlobalService } from './service/global.service';
import { Global } from './global';
import { Title, Meta } from '@angular/platform-browser';
import { LandingService } from '@vsecom/vs-ecom-storefront-services';

@Component({
  selector: 'app-root',
  templateUrl: './app.component.html',
  styleUrls: ['./app.component.css']
})

export class AppComponent implements OnInit {

  mainMenu: any = [];
  mainMenuMobile: any = [];
  showFloatingMenuIcon: boolean;
  showFloatingCloseIcon: boolean;
  showfloatingMenubar: boolean;
  showfloatingSearchbar: boolean;
  search: any = '';
  searchRequests: any = [];
  searchProductList: any = [];
  searchField = new FormControl();
  searchList: Observable<any>;
  searchValue: any;
  footer: any;
  searchbar: boolean; 
  matExpantValue: any = '';
  storeLogo: any;

  constructor(public global: Global, private landingService: LandingService, private httpClient: HttpClient, private activatedRoute: ActivatedRoute, private title: Title, private meta: Meta,
    public translateService: TranslateService, private globalService: GlobalService, private router: Router, @Inject(PLATFORM_ID) private platformId: object, @Inject(DOCUMENT) private document: Document) {
    translateService.use('en-us');
    this.searchList = this.searchField.valueChanges.pipe(
      startWith(''),
      debounceTime(400),
      distinctUntilChanged(),
      switchMap((value: any) => {
        return this.filter(value || '')
      })
    )
  }

  ngOnInit() {
    // Initial App Load
    this.initApplication();
    // For changing all pages meta information
    this.changeMetaInformation();
  }

  changeMetaInformation(){
    this.router.events.pipe(filter(e => e instanceof NavigationEnd), map(e => this.activatedRoute), map((route) => {
      while (route.firstChild) route = route.firstChild;
      return route;
    }), filter((route) => route.outlet === 'primary'), mergeMap((route) => route.data)).subscribe(data => {
      if (data['seo']) {
        let seoData = data['seo'];
        this.globalService.updateTitle(seoData['title']);
        this.globalService.updateMetaTags(seoData['metaTags']);
      }
    })
  }

  initApplication(){
    this.getScreenSize();
    this.getMenu();
    if (isPlatformBrowser(this.platformId)) {
      this.global.configData = JSON.parse(localStorage.getItem('configData'));
      this.global.cartlist = JSON.parse(localStorage.getItem('cartlist'));
      if (this.global.cartlist) {
        this.global.cartCount = this.global.cartlist.length;
      }
    }
    this.showFloatingMenuIcon = true;
  }

  getMenu() {
    this.landingService.GetMainMenu().subscribe((response: any) => {
      this.mainMenu = response;
    })
  }

  getScreenSize(event?) {
    if (isPlatformBrowser(this.platformId)) {
      this.footer = document.getElementById('footer').offsetHeight;
      let routerOutlets = document.getElementById('router');
      let footer = document.getElementById('footer');
      routerOutlets.style.paddingBottom = this.footer + 'px';
      footer.style.height = this.footer + 'px';
    }
  }

  showfloatingMenuIcon() {
    this.showFloatingCloseIcon = true;
    this.showFloatingMenuIcon = false;
    this.showfloatingMenubar = true;

  }

  showfloatingCloseIcon() {
    this.showFloatingMenuIcon = true;
    this.showFloatingCloseIcon = false;
    this.showfloatingMenubar = false;
  }

  showSearch() {
    this.showfloatingSearchbar = true;
  }

  closeSearch() {
    this.showfloatingSearchbar = false;
  }

  searchCatalogue(value) {
    if (value.ProductId) {
      this.router.navigate(['product/' + value.PermaLink + '/' + value.ProductId]);
      this.searchValue = '';
      this.showfloatingSearchbar = false;
    }
    else {
      this.router.navigate(['/search'], { queryParams: { search: value } });
    }
  }

  filter(val: any): Observable<any[]> {
    if(val == ""){
      val = null
    }
    return this.landingService.GetSearchProductList(val).pipe(map((response: any) => response.filter((option: any) => {
      return option;
    }))
    )
  }

  navigateLoginPage() {
    this.router.navigate(['login']);
  }

  navigateCartPage() {
    this.router.navigate(['cart']);
  }

  navigateProductsPage(e: any) {
    if(e.subCategoryId){
      this.router.navigate(['category/' + e.subCategoryName + '/' + e.subCategoryId]);
    }
    else{
      this.router.navigate(['category/' + e.PermaLink + '/' + e.categoryId]);
    }
  }

  navigateOffersPage() {
    this.router.navigate(['offers'])
  }

  navigateHomePage() {
    this.router.navigate([''])
  }

  navigateAccountPage() {
    this.router.navigate(['my-account']);
  }

  navigateOrderTrackingPage() {
    this.router.navigate(['tracking-orders']);
  }

  navigateChangePasswordPage() {
    this.router.navigate(['change-password']);
  }

  navigateLogout() {
    this.globalService.Logout();
  }


  navigateMobileOffersPage() {
    this.router.navigate(['offers']);
    this.showFloatingMenuIcon = true;
    this.showFloatingCloseIcon = false;
    this.showfloatingMenubar = false;
  }

  navigateMobileHomePage() {
    this.router.navigate(['home']);
    this.showFloatingMenuIcon = true;
    this.showFloatingCloseIcon = false;
    this.showfloatingMenubar = false;
  }

  navigateSearchPage() {
    this.router.navigate(['search']);
  }

  showSearchBar(){
    this.searchbar = true;
  }

  openfloatingMenu() {
    var body = document.body;
    document.getElementById('mobile-menu-overlay').classList.add('active');
    body.classList.add('no-overflow');
  }

  closeMobileMenu() {
    document.getElementById('mobile-menu-overlay').classList.remove('active');
  }

  
  navigateMobileProductsPage(PermaLink,categoryId){
    document.getElementById('mobile-menu-overlay').classList.remove('active');
    this.router.navigate(['category/' + PermaLink + '/' + categoryId]);
  }

  navigatemobileproductmage(subCategoryId,PermaLink){
    document.getElementById('mobile-menu-overlay').classList.remove('active');
    this.router.navigate(['category/' + PermaLink + '/' + subCategoryId]);
  }

  expandCategory(expandId: any) {
    if (expandId == this.matExpantValue) {
      this.matExpantValue = '';
    } else {
      this.matExpantValue = expandId;
    }
  }

  navigateSharedChangeEvent(event) {
    window.scrollTo(0,0);
    this.router.navigate([event.event]);
  }
}

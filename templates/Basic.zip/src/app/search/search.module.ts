import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';

import { SearchRoutingModule } from './search-routing.module';
import { SearchComponent } from './search.component';
import { VssuiteEcomModule } from '@vssuite/vs-angular-ecom-components';
import { NgxSpinnerModule } from 'ngx-spinner';

@NgModule({
  declarations: [SearchComponent],
  imports: [
    CommonModule,
    SearchRoutingModule,
    VssuiteEcomModule,
    NgxSpinnerModule
  ]
})
export class SearchModule { }

import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { ActivatedRoute, NavigationExtras, Router } from '@angular/router';
import { ProductService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../global';
import { CartService } from '@vsecom/vs-ecom-storefront-services';
import { isPlatformBrowser } from '@angular/common';
import { GlobalService } from '../service/global.service';
import { NgxSpinnerService } from 'ngx-spinner';
@Component({
  selector: 'app-search',
  templateUrl: './search.component.html',
  styleUrls: ['./search.component.css']
})
export class SearchComponent implements OnInit {

  searchString: string;
  searchProductRequests: any = [];
  lat: any = '';
  lng: any = '';
  request: any;
  priceRangeFrom: any;
  priceRangeTo: any;
  itemsPerPage = 50;
  products: any = [];
  productDataLength: any;
  currency: any;
  productExist: any;

  constructor(private router: Router, private route: ActivatedRoute, private productService: ProductService, public global: Global,
    private cartService: CartService, @Inject(PLATFORM_ID) private platformId: object, public globalService: GlobalService, private spinner: NgxSpinnerService) {
      this.route.queryParams.subscribe(async params => {
        this.searchString = params['search'];
        this.loadFilters();
      });
  }

  async ngOnInit() {
    if (isPlatformBrowser(this.platformId)) {
      this.global.configData = JSON.parse(localStorage.getItem('configData'))
      this.searchString = localStorage.getItem("productName");
      this.currency = localStorage.getItem('currency')
    }
  }

  loadFilters() {
    this.spinner.show();
    this.productService.GetMinMaxForProductSearch(this.searchString).subscribe((data: any) => {
      this.spinner.hide();
      if (data != null) {
        this.priceRangeFrom = data.min;
        this.priceRangeTo = data.max;
      }
      this.loadProducts();
    }, error => {
      this.spinner.hide();
    });
  }

  loadProducts() {
    this.spinner.show();
    this.productService.SearchCatalogue(this.searchString, null, this.priceRangeFrom, this.priceRangeTo, 1, this.itemsPerPage).subscribe((response: any) => {
      this.spinner.hide();
      this.products = response;
      if (this.products.length > 0) {
        this.productDataLength = this.products.length;
        this.products.totalCount = this.products[0].totalCount;
      }
    }, error => {
      this.spinner.hide();
    });
  }

  searchCatalogue(value) {
    var searchedProduct = value
    if (searchedProduct != null || searchedProduct != undefined) {
      let navigationExtras: NavigationExtras = {
        state: {
          productFilter: searchedProduct
        }
      };
      this.router.navigate(['/search'], navigationExtras)
    }
  }

}

import { Component, Inject, OnInit, PLATFORM_ID } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { MatDialogRef } from '@angular/material/dialog';
import { Router } from '@angular/router';
import { AuthService, CartService, UserActionService } from '@vsecom/vs-ecom-storefront-services';
import { Global } from '../../global';
import { GlobalService } from '../../service/global.service';
import { isPlatformBrowser } from '@angular/common';

@Component({
  selector: 'app-user-login',
  templateUrl: './user-login.component.html',
  styleUrls: ['./user-login.component.css']
})
export class UserLoginComponent implements OnInit {

  loginForm: FormGroup;
  message: any;
  savedSuccessfully: boolean = false;
  user: any = {};
  curUser: any = {};
  googleAuthToken: any = "";
  googleUser: any = {};
  submitted = false;
  flagError = false;
  
  constructor(public dialogRef: MatDialogRef<UserLoginComponent>, private router: Router,
    private global: Global, private globalService: GlobalService, @Inject(PLATFORM_ID) private platformId: object, private userActionService: UserActionService,
    private cartService: CartService, private authService: AuthService) { 
      this.loginForm = new FormGroup({
        UserName: new FormControl('', [Validators.required]),
        Password: new FormControl('', [Validators.required]),
    });
    }

    async ngOnInit() {
      this.globalService.GetLoggedInUserToken();
      if (isPlatformBrowser(this.platformId)) {
        this.global.userName = localStorage.getItem('userName');
        this.loadUserDefaults();
      }
      this.message = "";
    }

    login() {
      this.submitted = true;
      if (!this.loginForm.valid) {
        return;
      }
      if (this.loginForm.valid) {
        this.authService.Login(this.loginForm.value).subscribe((response) => {
          let tokenObj: any = {};
          Object.assign(tokenObj, response)
          this.globalService.SetLoggedInUserToken(tokenObj);
          this.global.flagLoggedIn = true;
          this.global.userName = this.loginForm.value.UserName;
          this.global.curUserDisplayName = '';
          this.dialogRef.close(true);
          this.loadUserDefaults();

        }, err => {
          this.message = err.error;
          this.global.flagLoggedIn = false;
          this.globalService.ClearCookieStore();
        });
      }
    }

    loadUserDefaults() {
      if (this.global.userName && this.global.userName.length > 0) {
        this.userActionService.GetUserDetails(this.global.userName).subscribe((response: any) => {
          this.curUser.Email = response.email;
          this.curUser.PhoneNumber1 = response.phoneNumber1;
          this.curUser.FirstName = response.firstName;
          this.curUser.LastName = response.lastName;
          this.global.curUserDisplayName = response.firstName;
          // this.router.navigate(['home'])
          if (response.email || response.phoneNumber1) {
            if (isPlatformBrowser(this.platformId)) {
              localStorage.setItem('flagLoggedIn', this.global.flagLoggedIn);
              localStorage.setItem('userName', this.global.userName);
              localStorage.setItem('curUserDisplayName', this.global.curUserDisplayName);
            }
          }
          if (this.global.cartlist && this.global.cartlist.length > 0) {
            this.cartService.AddShoppingCartItemList(this.global.cartlist, this.global.userName)
              .subscribe((response: any) => {
                this.getShoppingCartItems();
              });
          }
          else {
            this.getShoppingCartItems();
          }
        });
      }
      else {
        return;
      }
    }

    getShoppingCartItems() {
      this.cartService.GetShoppingCartItems(this.global.userName).subscribe((response: any) => {
        if (response && response.length > 0) {
          this.global.cartlist = [];
          for (var i = 0; i < response.length; i++) {
            let addtoCartProduct = this.createCartListProductObjectFromList(response[i]);
  
            this.global.cartlist.push(addtoCartProduct);
          }
          if (this.global.cartlist && this.global.cartlist.length > 0) {
            if (isPlatformBrowser(this.platformId)) {
              localStorage.setItem('cartlist', JSON.stringify(this.global.cartlist));
            }
          }
          else {
            if (isPlatformBrowser(this.platformId)) {
              this.global.cartlist = JSON.parse(localStorage.getItem('cartlist'));
            }
          }
        }
        this.globalService.CalculateCartTotal();
      });
    }
  
    createCartListProductObjectFromList(product: any) {
      if (product.productId > 0) {
        let cart: any = {};
        cart.ProductId = product.productId;
        cart.Name = product.name;
        cart.PictureName = product.pictureName;
        cart.SpecialPrice = product.specialPrice;
        cart.Price = product.price;
        cart.Branch = product.branch;
        cart.BranchId = product.branchId;
        cart.StoresCount = product.storesCount;
        cart.FlagWishlist = product.flagWishlist;
        cart.Quantity = product.quantity;
        cart.SelectedSize = product.selectedSize;
        cart.AdditionalShippingCharge = product.additionalShippingCharge;
        cart.TotalAdditionalShippingCharge = product.additionalShippingCharge * cart.Quantity;
        cart.SubTotal = (cart.SpecialPrice * cart.Quantity);
        cart.SubTotalWithShipping = (cart.SpecialPrice * cart.Quantity) + cart.TotalAdditionalShippingCharge;
        return cart;
      }
    }

    close(){ 
      this.dialogRef.close();
    }

    navigatingForgotPassword() {
      this.close();
      this.router.navigate(['/forgot-password']);
    }
  
    navigatingRegister() {
      this.close();
      this.router.navigate(['/register']);
    }

    navigatingLogin(){
      this.close();
      this.router.navigate(['/login']);
    }
}

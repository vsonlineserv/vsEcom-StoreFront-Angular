import { Component, OnInit } from '@angular/core';
import { DomSanitizer } from '@angular/platform-browser';
import { ActivatedRoute, Router } from '@angular/router';
import { GlobalService } from 'src/app/service/global.service';

@Component({
  selector: 'app-shared',
  templateUrl: './shared.component.html',
  styleUrls: ['./shared.component.css']
})
export class SharedComponent implements OnInit {

  sharedContent: any;
  content: any;

  constructor(private globalService: GlobalService, private sanitizer: DomSanitizer, private activatedRoute: ActivatedRoute, private router: Router) {
  }


  ngOnInit() {
    this.content = this.activatedRoute.routeConfig.path;
    this.loadSharedContent();
  }

  loadSharedContent() {
    this.globalService.getSharedContent(this.content).subscribe((data: any) => {
      this.sharedContent = this.sanitizer.bypassSecurityTrustHtml(data);
    })
  }
}

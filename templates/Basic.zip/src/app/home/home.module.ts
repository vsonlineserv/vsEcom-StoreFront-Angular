import { NgModule } from '@angular/core';
import { CommonModule } from '@angular/common';
import { HomeRoutingModule } from './home-routing.module';
import { HomeComponent } from './home.component';
import { TranslateModule } from '@ngx-translate/core';
import { VsEcomStorefrontServicesModule } from '@vsecom/vs-ecom-storefront-services';
import { VssuiteEcomModule } from '@vssuite/vs-angular-ecom-components';
import { NgbModule } from '@ng-bootstrap/ng-bootstrap';

@NgModule({
  declarations: [HomeComponent],
  imports: [
    CommonModule,
    HomeRoutingModule,
    TranslateModule,
    VssuiteEcomModule,
    VsEcomStorefrontServicesModule,
    NgbModule,

  ]
})
export class HomeModule { }

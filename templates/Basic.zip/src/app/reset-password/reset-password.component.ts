import { Component, OnInit } from '@angular/core';
import { FormControl, FormGroup, Validators } from '@angular/forms';
import { ActivatedRoute, Router } from '@angular/router';
import { PasswordService } from '@vsecom/vs-ecom-storefront-services';

@Component({
  selector: 'app-reset-password',
  templateUrl: './reset-password.component.html',
  styleUrls: ['./reset-password.component.css']
})
export class ResetPasswordComponent implements OnInit {

  message: any = '';
  uId: any = '';
  userName: any = '';
  resetPasswordForm: FormGroup;
  submitted: boolean = false;
  isErrorOccurred: boolean = false;
  passwordVisible: boolean = false;
  passwordVisible1: boolean = false;

  constructor(private route: ActivatedRoute, private passwordService: PasswordService) {
    this.route.queryParams.subscribe(params => {
      if (params['uId'] != null && params['userName'] != null) {
        this.uId = params['uId'];
        this.userName = params['userName']
      }
    });
    this.resetPasswordForm = new FormGroup({
      NewPassword: new FormControl('', [Validators.required]),
      ConfirmPassword: new FormControl('', [Validators.required]),
    });
  }

  ngOnInit() {

    
  }
  togglePasswordVisibility() {
    let npw: any;
    npw = document.getElementById("newPassword");
    if (npw.type === "password") {
      npw.type = "text";
      this.passwordVisible = true;
    } else {
      npw.type = "password";
      this.passwordVisible = false;
    }
  }
  togglePasswordVisibility1() {
    let npw: any;
    npw = document.getElementById("newPassword1");
    if (npw.type === "password") {
      npw.type = "text";
      this.passwordVisible1 = true;
    } else {
      npw.type = "password";
      this.passwordVisible1 = false;
    }
  }

  resetPassword() {
    this.submitted = true;
    if (!this.resetPasswordForm.valid) {
      return;
    }
    if (this.resetPasswordForm.value.NewPassword === this.resetPasswordForm.value.ConfirmPassword) {
      let data = {
        UniqueId: this.uId,
        UserName: this.userName,
        Password: this.resetPasswordForm.value.NewPassword
      }
      this.passwordService.ResetPassword(data).subscribe((response) => {
        if (response) {
          this.isErrorOccurred = false;
          this.message = 'Your password has been reset successfully';
          this.submitted = false;
        }
        else {
          this.isErrorOccurred = true;
          this.message = 'There is some error occurred, please try again later';
          this.submitted = false;

        }
      }, error => {
        this.isErrorOccurred = true;
        this.message = 'There is some error occurred, please try again later';
      });
    }
    else {
      this.submitted = false;
      this.isErrorOccurred = true;
      this.message = 'New Password and Confirm Password must be match'
    }
  }

}

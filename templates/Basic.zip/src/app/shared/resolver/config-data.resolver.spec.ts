import { TestBed } from '@angular/core/testing';

import { ConfigDataResolver } from './config-data.resolver';

describe('ConfigDataResolver', () => {
  let resolver: ConfigDataResolver;

  beforeEach(() => {
    TestBed.configureTestingModule({});
    resolver = TestBed.inject(ConfigDataResolver);
  });

  it('should be created', () => {
    expect(resolver).toBeTruthy();
  });
});

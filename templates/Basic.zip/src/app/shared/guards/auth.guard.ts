import { Injectable } from "@angular/core";
import {
    ActivatedRouteSnapshot,
    CanActivate,
    Router,
    RouterStateSnapshot,
    UrlTree
} from "@angular/router";
import { GlobalService } from "src/app/service/global.service";

@Injectable()
export class AuthGuard implements CanActivate {
    constructor(
        private globalService: GlobalService,
        private router: Router) { }
    canActivate(
        route: ActivatedRouteSnapshot,
        state: RouterStateSnapshot): boolean | Promise<boolean> {
        var tokenExists = this.globalService.checkTokenExist();
        var isAuthenticated = this.globalService.checkTokenValid();
        var isFlagVerified = this.globalService.checkIsAuthenticated();
        if (!tokenExists || !isFlagVerified || !isAuthenticated) {
            this.router.navigate(['/login']);
            return false;
        }
        return true
    }
}